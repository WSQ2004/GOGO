package com.kaoyan.timer.ui.screens.stats

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.kaoyan.timer.KaoyanApp
import com.kaoyan.timer.ai.AIClient
import com.kaoyan.timer.ai.AIRepository
import com.kaoyan.timer.data.local.dao.DailyTotal
import com.kaoyan.timer.data.local.dao.SubjectStat
import com.kaoyan.timer.util.DateUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

enum class StatsRange { DAY, WEEK, MONTH }

data class StatsUiState(
    val range: StatsRange = StatsRange.WEEK,
    val totalMinutes: Int = 0,
    val dailyTarget: Int = 480,
    val examDate: String = "2026-12-21",
    val subjectStats: List<SubjectStat> = emptyList(),
    val dailyTotals: List<DailyTotal> = emptyList(),
    val aiAnalysis: String = "",
    val isAnalyzing: Boolean = false,
    val aiError: String? = null
)

class StatsViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as KaoyanApp
    private val recordRepo = app.studyRecordRepository
    private val settingsPref = app.settingsPref

    private val _uiState = MutableStateFlow(StatsUiState())
    val uiState: StateFlow<StatsUiState> = _uiState.asStateFlow()

    private var aiRepository: AIRepository? = null

    init {
        loadData(StatsRange.WEEK)
        viewModelScope.launch {
            settingsPref.dailyTarget.collect { target ->
                _uiState.value = _uiState.value.copy(dailyTarget = target)
            }
        }
        viewModelScope.launch {
            settingsPref.examDate.collect { date ->
                _uiState.value = _uiState.value.copy(examDate = date)
            }
        }
        viewModelScope.launch {
            combine(settingsPref.aiApiKey, settingsPref.aiApiBase, settingsPref.aiModel) { key, base, model ->
                aiRepository = if (key.isNotBlank()) {
                    AIRepository(AIClient(key, base, model))
                } else null
            }.collect { }
        }
    }

    fun setRange(range: StatsRange) {
        _uiState.value = _uiState.value.copy(range = range, aiAnalysis = "")
        loadData(range)
    }

    private fun loadData(range: StatsRange) {
        val (start, end) = when (range) {
            StatsRange.DAY -> DateUtils.today() to DateUtils.today()
            StatsRange.WEEK -> DateUtils.getDateRange(7)
            StatsRange.MONTH -> DateUtils.getDateRange(30)
        }

        viewModelScope.launch {
            combine(
                recordRepo.getTotalMinutesByDateRange(start, end),
                recordRepo.getSubjectStatsByDateRange(start, end),
                recordRepo.getDailyTotalsByDateRange(start, end)
            ) { total, subjects, daily ->
                _uiState.value.copy(
                    totalMinutes = total,
                    subjectStats = subjects,
                    dailyTotals = daily
                )
            }.collect { _uiState.value = it }
        }
    }

    fun generateAnalysis() {
        val repo = aiRepository
        if (repo == null) {
            _uiState.value = _uiState.value.copy(aiError = "请先在设置中配置 AI API Key")
            return
        }

        val state = _uiState.value
        _uiState.value = state.copy(isAnalyzing = true, aiError = null)

        viewModelScope.launch {
            try {
                val result = repo.generateAnalysis(
                    subjectStats = state.subjectStats,
                    dailyTotals = state.dailyTotals,
                    totalMinutes = state.totalMinutes,
                    dailyTarget = state.dailyTarget,
                    examDate = state.examDate
                )
                result.fold(
                    onSuccess = { analysis ->
                        _uiState.value = _uiState.value.copy(
                            aiAnalysis = analysis,
                            isAnalyzing = false
                        )
                    },
                    onFailure = { e ->
                        _uiState.value = _uiState.value.copy(
                            aiError = e.message ?: "分析失败",
                            isAnalyzing = false
                        )
                    }
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    aiError = "异常: ${e.message}",
                    isAnalyzing = false
                )
            }
        }
    }
}
