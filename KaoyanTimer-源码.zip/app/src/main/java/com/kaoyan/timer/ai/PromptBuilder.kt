package com.kaoyan.timer.ai

import com.kaoyan.timer.data.local.dao.DailyTotal
import com.kaoyan.timer.data.local.dao.SubjectStat
import com.kaoyan.timer.util.DateUtils
import com.kaoyan.timer.util.TimeUtils

object PromptBuilder {

    fun buildAnalysisPrompt(
        subjectStats: List<SubjectStat>,
        dailyTotals: List<DailyTotal>,
        totalMinutes: Int,
        dailyTarget: Int,
        examDate: String
    ): String {
        val subjectInfo = subjectStats.joinToString("\n") {
            "- ${it.subjectName}: ${TimeUtils.formatMinutes(it.total)}"
        }
        val dailyInfo = dailyTotals.joinToString("\n") {
            "- ${it.date}: ${TimeUtils.formatMinutes(it.total)}"
        }
        val daysLeft = DateUtils.daysUntil(examDate)

        return """
你是一位专业的考研学习规划顾问。请根据以下学习数据，为用户生成一份简洁有力的学习分析报告。

【基本信息】
- 统计周期：最近7天
- 总学习时长：${TimeUtils.formatMinutes(totalMinutes)}
- 每日目标：${TimeUtils.formatMinutes(dailyTarget)}
- 距离考研还有：${daysLeft}天

【各科学习时长】
$subjectInfo

【每日学习时长】
$dailyInfo

请按以下结构输出（使用Markdown格式）：
1. **总体评价**：一句话概括本周学习状态
2. **亮点分析**：做得好的地方（1-2点）
3. **问题指出**：需要改进的地方（1-2点，要具体）
4. **下周建议**：可执行的具体建议（2-3条）
5. **鼓励语**：一句激励的话

要求：语言真诚、直接、不空洞，数据要具体引用，总字数控制在300字以内。
        """.trimIndent()
    }

    fun buildChatSystemPrompt(examDate: String, assistantName: String = "小研"): String {
        val daysLeft = DateUtils.daysUntil(examDate)
        return """
你是一位专业的考研学习助手，名字叫"${assistantName}"，距离考研还有${daysLeft}天。
你的职责：
1. 回答考研相关的学习方法、科目规划、心态调整问题
2. 根据用户的学习数据给出个性化建议
3. 鼓励用户，帮助保持学习动力
4. 回答要简洁实用，避免空话套话
5. 当用户称呼你的名字时，要有亲切感
请用中文回答。
        """.trimIndent()
    }

    fun buildReminderPrompt(
        todayMinutes: Int,
        dailyTarget: Int,
        subjectStats: List<SubjectStat>,
        examDate: String
    ): String {
        val subjectInfo = subjectStats.joinToString("、") { it.subjectName }
        val daysLeft = DateUtils.daysUntil(examDate)
        val progress = if (dailyTarget > 0) (todayMinutes * 100 / dailyTarget) else 0

        return """
你是考研学习提醒助手。根据以下情况生成一条简短的学习提醒（50字以内）：
- 今日已学：${TimeUtils.formatMinutes(todayMinutes)}（目标${TimeUtils.formatMinutes(dailyTarget)}，完成${progress}%）
- 已学科目：$subjectInfo
- 距离考研：${daysLeft}天

要求：语气亲切但有推动力，根据完成度给出不同的提醒（完成度低要督促，完成度高要鼓励）。
        """.trimIndent()
    }

    fun buildStudyPlanPrompt(
        subjects: String,
        dailyHours: Float,
        examDate: String,
        subjectStats: List<SubjectStat>
    ): String {
        val daysLeft = DateUtils.daysUntil(examDate)
        val subjectInfo = if (subjectStats.isNotEmpty()) {
            subjectStats.joinToString("\n") { "- ${it.subjectName}: 最近7天学了${TimeUtils.formatMinutes(it.total)}" }
        } else "暂无学习数据"

        return """
请根据以下信息，为我生成一份详细的考研学习计划：

【基本信息】
- 距离考研：${daysLeft}天
- 备考科目：$subjects
- 每天可用时间：${dailyHours}小时
- 每日学习目标：${TimeUtils.formatMinutes((dailyHours * 60).toInt())}

【最近学习数据】
$subjectInfo

请按以下结构输出：
1. **总体规划**：根据剩余天数和科目，给出整体复习节奏建议
2. **每日时间分配**：每科每天分配多少时间，什么时间段学什么
3. **各科复习重点**：针对每个科目，给出当前阶段的复习重点和方法
4. **每周进度目标**：每周应该完成什么
5. **注意事项**：作息、心态、刷题技巧等建议

要求：具体、可执行、不空洞，总字数控制在500字以内。
        """.trimIndent()
    }

    fun buildMotivationPrompt(
        todayMinutes: Int,
        dailyTarget: Int,
        examDate: String
    ): String {
        val daysLeft = DateUtils.daysUntil(examDate)
        val progress = if (dailyTarget > 0) (todayMinutes * 100 / dailyTarget) else 0

        return """
请根据以下情况，给我生成一句温暖有力的考研激励语（50字以内）：
- 距离考研：${daysLeft}天
- 今日已学：${TimeUtils.formatMinutes(todayMinutes)}（完成${progress}%）

要求：
- 如果完成度低于50%，语气温柔但有推动力，不要指责
- 如果完成度在50%-80%，给予肯定并鼓励继续
- 如果完成度超过80%，热烈表扬并提醒注意休息
- 要有画面感和情感共鸣，不要用陈词滥调
        """.trimIndent()
    }

    fun buildStudySummaryPrompt(
        subjectName: String,
        durationMinutes: Int,
        note: String,
        todayMinutes: Int,
        dailyTarget: Int,
        examDate: String
    ): String {
        val daysLeft = DateUtils.daysUntil(examDate)
        val progress = if (dailyTarget > 0) (todayMinutes * 100 / dailyTarget) else 0

        return """
你是考研学习助手。用户刚刚完成了一段学习，请生成一句简短的学习反馈（30字以内）：

【本次学习】
- 科目：$subjectName
- 时长：${TimeUtils.formatMinutes(durationMinutes)}
- 笔记：${note.ifBlank { "无"}}

【今日进度】
- 今日已学：${TimeUtils.formatMinutes(todayMinutes)}（目标${TimeUtils.formatMinutes(dailyTarget)}，完成${progress}%）
- 距离考研：${daysLeft}天

要求：
- 根据本次学习时长和今日进度给出反馈
- 学的时间长要肯定，学的时间短要鼓励继续
- 可以结合科目给出简单建议
- 语气亲切，像朋友一样
- 不要超过30字
        """.trimIndent()
    }

    fun buildReviewPrompt(
        subjectStats: List<SubjectStat>,
        examDate: String
    ): String {
        val daysLeft = DateUtils.daysUntil(examDate)
        val subjectInfo = if (subjectStats.isNotEmpty()) {
            subjectStats.joinToString("\n") {
                "- ${it.subjectName}: 最近7天学了${TimeUtils.formatMinutes(it.total)}"
            }
        } else "暂无学习数据"

        return """
你是考研复习规划专家。请根据艾宾浩斯遗忘曲线原理，为用户生成一份复习提醒计划：

【用户学习数据】
$subjectInfo

【基本信息】
- 距离考研：${daysLeft}天

请按以下结构输出：
1. **艾宾浩斯复习原理简述**（1-2句话，让用户理解为什么要及时复习）
2. **今日复习建议**：根据最近学习的科目，建议今天重点复习哪些内容
3. **未来7天复习安排**：按照1天、2天、4天、7天的复习节点，给出每天的复习重点
4. **各科复习策略**：针对每个科目，给出符合该科目特点的复习方法
5. **注意事项**：复习时的注意事项和效率提升技巧

要求：
- 具体、可执行，不要空泛
- 结合用户的实际学习数据
- 总字数控制在400字以内
- 用中文回答
        """.trimIndent()
    }
}
