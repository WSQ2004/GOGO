package com.kaoyan.timer.util

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

object DateUtils {

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    private val dateTimeFormat = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
    private val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
    private val monthDayFormat = SimpleDateFormat("MM/dd", Locale.getDefault())
    private val weekDayFormat = SimpleDateFormat("EE", Locale.CHINA)

    fun today(): String = dateFormat.format(Date())

    fun formatDate(timestamp: Long): String = dateFormat.format(Date(timestamp))

    fun formatDateTime(timestamp: Long): String = dateTimeFormat.format(Date(timestamp))

    fun formatTime(timestamp: Long): String = timeFormat.format(Date(timestamp))

    fun formatMonthDay(dateStr: String): String {
        return try {
            val date = dateFormat.parse(dateStr)
            monthDayFormat.format(date!!)
        } catch (e: Exception) {
            dateStr
        }
    }

    fun formatWeekDay(dateStr: String): String {
        return try {
            val date = dateFormat.parse(dateStr)
            weekDayFormat.format(date!!)
        } catch (e: Exception) {
            ""
        }
    }

    fun getDateRange(days: Int): Pair<String, String> {
        val cal = Calendar.getInstance()
        val end = dateFormat.format(cal.time)
        cal.add(Calendar.DAY_OF_YEAR, -(days - 1))
        val start = dateFormat.format(cal.time)
        return Pair(start, end)
    }

    fun getWeekRange(): Pair<String, String> {
        val cal = Calendar.getInstance()
        cal.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
        val start = dateFormat.format(cal.time)
        cal.add(Calendar.DAY_OF_YEAR, 6)
        val end = dateFormat.format(cal.time)
        return Pair(start, end)
    }

    fun getMonthRange(): Pair<String, String> {
        val cal = Calendar.getInstance()
        cal.set(Calendar.DAY_OF_MONTH, 1)
        val start = dateFormat.format(cal.time)
        cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH))
        val end = dateFormat.format(cal.time)
        return Pair(start, end)
    }

    fun getLast7Days(): List<String> {
        val days = mutableListOf<String>()
        val cal = Calendar.getInstance()
        for (i in 6 downTo 0) {
            cal.add(Calendar.DAY_OF_YEAR, -i)
            days.add(dateFormat.format(cal.time))
            cal.add(Calendar.DAY_OF_YEAR, i)
        }
        return days
    }

    fun daysBetween(startDate: String, endDate: String): Long {
        return try {
            val start = dateFormat.parse(startDate)
            val end = dateFormat.parse(endDate)
            TimeUnit.MILLISECONDS.toDays(end!!.time - start!!.time)
        } catch (e: Exception) {
            0
        }
    }

    fun daysUntil(targetDate: String): Long {
        return daysBetween(today(), targetDate)
    }

    fun parseDate(dateStr: String): Date? {
        return try {
            dateFormat.parse(dateStr)
        } catch (e: Exception) {
            null
        }
    }
}
