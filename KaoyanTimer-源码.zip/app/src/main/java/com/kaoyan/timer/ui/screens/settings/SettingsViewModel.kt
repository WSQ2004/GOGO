package com.kaoyan.timer.ui.screens.settings

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.kaoyan.timer.KaoyanApp
import com.kaoyan.timer.data.local.entity.Subject
import com.kaoyan.timer.ui.theme.SubjectColors
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class SettingsUiState(
    val examDate: String = "2026-12-21",
    val dailyTarget: Int = 480,
    val pomodoroWork: Int = 25,
    val pomodoroBreak: Int = 5,
    val aiApiKey: String = "",
    val aiApiBase: String = "https://api.openai.com/v1",
    val aiModel: String = "gpt-3.5-turbo",
    val aiAssistantName: String = "小研",
    val themeMode: Int = 0,
    val subjects: List<Subject> = emptyList()
)

class SettingsViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as KaoyanApp
    private val settingsPref = app.settingsPref
    private val subjectRepo = app.subjectRepository

    private val _uiState = MutableStateFlow(SettingsUiState())
    val uiState: StateFlow<SettingsUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            settingsPref.examDate.collect { _uiState.value = _uiState.value.copy(examDate = it) }
        }
        viewModelScope.launch {
            settingsPref.dailyTarget.collect { _uiState.value = _uiState.value.copy(dailyTarget = it) }
        }
        viewModelScope.launch {
            settingsPref.pomodoroWork.collect { _uiState.value = _uiState.value.copy(pomodoroWork = it) }
        }
        viewModelScope.launch {
            settingsPref.pomodoroBreak.collect { _uiState.value = _uiState.value.copy(pomodoroBreak = it) }
        }
        viewModelScope.launch {
            settingsPref.aiApiKey.collect { _uiState.value = _uiState.value.copy(aiApiKey = it) }
        }
        viewModelScope.launch {
            settingsPref.aiApiBase.collect { _uiState.value = _uiState.value.copy(aiApiBase = it) }
        }
        viewModelScope.launch {
            settingsPref.aiModel.collect { _uiState.value = _uiState.value.copy(aiModel = it) }
        }
        viewModelScope.launch {
            settingsPref.aiAssistantName.collect { _uiState.value = _uiState.value.copy(aiAssistantName = it) }
        }
        viewModelScope.launch {
            settingsPref.themeMode.collect { _uiState.value = _uiState.value.copy(themeMode = it) }
        }
        viewModelScope.launch {
            subjectRepo.getAllSubjects().collect { _uiState.value = _uiState.value.copy(subjects = it) }
        }
    }

    fun setExamDate(date: String) = viewModelScope.launch { settingsPref.setExamDate(date) }
    fun setDailyTarget(minutes: Int) = viewModelScope.launch { settingsPref.setDailyTarget(minutes) }
    fun setPomodoroWork(minutes: Int) = viewModelScope.launch { settingsPref.setPomodoroWork(minutes) }
    fun setPomodoroBreak(minutes: Int) = viewModelScope.launch { settingsPref.setPomodoroBreak(minutes) }
    fun setAiApiKey(key: String) = viewModelScope.launch { settingsPref.setAiApiKey(key) }
    fun setAiApiBase(base: String) = viewModelScope.launch { settingsPref.setAiApiBase(base) }
    fun setAiModel(model: String) = viewModelScope.launch { settingsPref.setAiModel(model) }
    fun setAiAssistantName(name: String) = viewModelScope.launch { settingsPref.setAiAssistantName(name) }
    fun setThemeMode(mode: Int) = viewModelScope.launch { settingsPref.setThemeMode(mode) }

    fun addSubject(name: String) {
        viewModelScope.launch {
            val color = SubjectColors[_uiState.value.subjects.size % SubjectColors.size].value.toLong()
            subjectRepo.insert(Subject(name = name, color = color, icon = "📚", isCustom = true))
        }
    }

    fun deleteSubject(subject: Subject) {
        viewModelScope.launch { subjectRepo.delete(subject) }
    }
}
