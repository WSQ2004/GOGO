package com.kaoyan.timer.ui.screens.ai

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.kaoyan.timer.KaoyanApp
import com.kaoyan.timer.ai.AIClient
import com.kaoyan.timer.ai.AIRepository
import com.kaoyan.timer.ai.PromptBuilder
import com.kaoyan.timer.data.local.dao.SubjectStat
import com.kaoyan.timer.util.DateUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

data class ChatMessage(
    val role: String, // user / assistant
    val content: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class AIUiState(
    val messages: List<ChatMessage> = emptyList(),
    val isLoading: Boolean = false,
    val error: String? = null,
    val examDate: String = "2026-12-21",
    val todayMinutes: Int = 0,
    val dailyTarget: Int = 480,
    val subjectStats: List<SubjectStat> = emptyList(),
    val isConfigured: Boolean = false,
    val assistantName: String = "小研",
    val historyQuestions: List<String> = emptyList()
)

class AIViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as KaoyanApp
    private val recordRepo = app.studyRecordRepository
    private val chatRepo = app.chatRepository
    private val settingsPref = app.settingsPref

    private val _uiState = MutableStateFlow(AIUiState())
    val uiState: StateFlow<AIUiState> = _uiState.asStateFlow()

    @Volatile
    private var aiRepository: AIRepository? = null

    // 记录当前 AI 配置，用于判断是否需要重建 repository
    @Volatile
    private var currentApiConfig: Triple<String, String, String>? = null

    init {
        observeConfigAndStats()
        observeChatMessages()
        loadHistoryQuestions()
    }

    private fun loadHistoryQuestions() {
        viewModelScope.launch {
            val questions = chatRepo.getRecentUserQuestions(10)
            _uiState.value = _uiState.value.copy(historyQuestions = questions)
        }
    }

    private fun observeChatMessages() {
        viewModelScope.launch {
            chatRepo.allMessages
                .catch { e ->
                    Log.e("AIViewModel", "Chat messages flow error", e)
                }
                .collect { messages ->
                    _uiState.value = _uiState.value.copy(messages = messages)
                    // 同步刷新历史问题列表
                    val questions = chatRepo.getRecentUserQuestions(10)
                    _uiState.value = _uiState.value.copy(historyQuestions = questions)
                }
        }
    }

    private fun observeConfigAndStats() {
        viewModelScope.launch {
            val apiConfig = combine(
                settingsPref.aiApiKey,
                settingsPref.aiApiBase,
                settingsPref.aiModel
            ) { key, base, model -> Triple(key, base, model) }

            val dateRange = DateUtils.getDateRange(7)

            // 合并三个设置流，避免超过 combine 的5参数限制
            val settingsConfig = combine(
                settingsPref.examDate,
                settingsPref.dailyTarget,
                settingsPref.aiAssistantName
            ) { examDate, target, name -> Triple(examDate, target, name) }

            combine(
                settingsConfig,
                apiConfig,
                recordRepo.getTotalMinutesByDate(DateUtils.today()),
                recordRepo.getSubjectStatsByDateRange(dateRange.first, dateRange.second)
            ) { config, api, today, subjects ->
                val examDate = config.first
                val target = config.second
                val assistantName = config.third

                // 配置（key/base/model）任一变化都重建 repository
                val needsNewRepo = currentApiConfig != api
                if (needsNewRepo) {
                    currentApiConfig = api
                    aiRepository = if (api.first.isNotBlank()) {
                        AIRepository(AIClient(api.first, api.second, api.third))
                    } else null
                }

                AIUiState(
                    examDate = examDate,
                    dailyTarget = target,
                    todayMinutes = today,
                    subjectStats = subjects,
                    isConfigured = api.first.isNotBlank(),
                    assistantName = assistantName
                )
            }
                .catch { e ->
                    Log.e("AIViewModel", "Config flow error", e)
                    emit(_uiState.value.copy(error = "数据加载失败: ${e.message ?: "未知错误"}"))
                }
                .collect { newState ->
                    _uiState.value = newState.copy(
                        messages = _uiState.value.messages,
                        isLoading = _uiState.value.isLoading,
                        error = _uiState.value.error
                    )
                }
        }
    }

    fun sendMessage(message: String) {
        val repo = aiRepository
        if (repo == null) {
            _uiState.value = _uiState.value.copy(error = "请先在设置中配置 AI API Key")
            return
        }

        val history = _uiState.value.messages
            .map { it.role to it.content }
            .takeLast(10)

        viewModelScope.launch {
            chatRepo.saveMessage("user", message)
            _uiState.value = _uiState.value.copy(isLoading = true, error = null)

            try {
                val result = repo.chat(
                    userMessage = message,
                    history = history,
                    examDate = _uiState.value.examDate,
                    assistantName = _uiState.value.assistantName
                )
                result.fold(
                    onSuccess = { reply ->
                        chatRepo.saveMessage("assistant", reply)
                        _uiState.value = _uiState.value.copy(isLoading = false)
                    },
                    onFailure = { e ->
                        Log.e("AIViewModel", "Chat failed", e)
                        chatRepo.saveMessage("assistant", "抱歉，出错了：${e.message}")
                        _uiState.value = _uiState.value.copy(isLoading = false, error = e.message)
                    }
                )
            } catch (e: Exception) {
                Log.e("AIViewModel", "Unexpected error in sendMessage", e)
                chatRepo.saveMessage("assistant", "发生异常：${e.message}")
                _uiState.value = _uiState.value.copy(isLoading = false, error = e.message)
            }
        }
    }

    fun generateAnalysisReport() {
        val repo = aiRepository
        if (repo == null) {
            _uiState.value = _uiState.value.copy(error = "请先在设置中配置 AI API Key")
            return
        }

        viewModelScope.launch {
            chatRepo.saveMessage("user", "帮我分析一下最近的学习情况")
            _uiState.value = _uiState.value.copy(isLoading = true, error = null)

            try {
                val dateRange = DateUtils.getDateRange(7)
                val dailyTotals = recordRepo.getDailyTotalsByDateRange(dateRange.first, dateRange.second)
                val totalMinutes = recordRepo.getTotalMinutesByDateRange(dateRange.first, dateRange.second)

                // 从 Flow 中获取当前值
                var dailyList = emptyList<com.kaoyan.timer.data.local.dao.DailyTotal>()
                var total = 0
                val job1 = launch { dailyTotals.collect { dailyList = it } }
                val job2 = launch { totalMinutes.collect { total = it } }
                kotlinx.coroutines.delay(300)
                job1.cancel()
                job2.cancel()

                val result = repo.generateAnalysis(
                    subjectStats = _uiState.value.subjectStats,
                    dailyTotals = dailyList,
                    totalMinutes = total,
                    dailyTarget = _uiState.value.dailyTarget,
                    examDate = _uiState.value.examDate
                )
                result.fold(
                    onSuccess = { reply ->
                        chatRepo.saveMessage("assistant", reply)
                        _uiState.value = _uiState.value.copy(isLoading = false)
                    },
                    onFailure = { e ->
                        chatRepo.saveMessage("assistant", "生成分析报告失败：${e.message}")
                        _uiState.value = _uiState.value.copy(isLoading = false, error = e.message)
                    }
                )
            } catch (e: Exception) {
                Log.e("AIViewModel", "Analysis report error", e)
                chatRepo.saveMessage("assistant", "生成分析报告异常：${e.message}")
                _uiState.value = _uiState.value.copy(isLoading = false, error = e.message)
            }
        }
    }

    fun generateStudyPlan(subjects: String, dailyHours: Float) {
        val repo = aiRepository
        if (repo == null) {
            _uiState.value = _uiState.value.copy(error = "请先在设置中配置 AI API Key")
            return
        }

        viewModelScope.launch {
            chatRepo.saveMessage("user", "帮我生成学习计划，科目：$subjects，每天可用${dailyHours}小时")
            _uiState.value = _uiState.value.copy(isLoading = true, error = null)

            try {
                val prompt = PromptBuilder.buildStudyPlanPrompt(
                    subjects = subjects,
                    dailyHours = dailyHours,
                    examDate = _uiState.value.examDate,
                    subjectStats = _uiState.value.subjectStats
                )
                val result = repo.chat(
                    userMessage = prompt,
                    history = emptyList(),
                    examDate = _uiState.value.examDate,
                    assistantName = _uiState.value.assistantName
                )
                result.fold(
                    onSuccess = { reply ->
                        chatRepo.saveMessage("assistant", reply)
                        _uiState.value = _uiState.value.copy(isLoading = false)
                    },
                    onFailure = { e ->
                        chatRepo.saveMessage("assistant", "生成学习计划失败：${e.message}")
                        _uiState.value = _uiState.value.copy(isLoading = false, error = e.message)
                    }
                )
            } catch (e: Exception) {
                chatRepo.saveMessage("assistant", "生成学习计划异常：${e.message}")
                _uiState.value = _uiState.value.copy(isLoading = false, error = e.message)
            }
        }
    }

    fun generateDailyMotivation() {
        val repo = aiRepository
        if (repo == null) {
            _uiState.value = _uiState.value.copy(error = "请先在设置中配置 AI API Key")
            return
        }

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, error = null)
            try {
                val prompt = PromptBuilder.buildMotivationPrompt(
                    todayMinutes = _uiState.value.todayMinutes,
                    dailyTarget = _uiState.value.dailyTarget,
                    examDate = _uiState.value.examDate
                )
                val result = repo.chat(
                    userMessage = prompt,
                    history = emptyList(),
                    examDate = _uiState.value.examDate,
                    assistantName = _uiState.value.assistantName
                )
                result.fold(
                    onSuccess = { reply ->
                        chatRepo.saveMessage("assistant", reply)
                        _uiState.value = _uiState.value.copy(isLoading = false)
                    },
                    onFailure = { e ->
                        _uiState.value = _uiState.value.copy(isLoading = false, error = e.message)
                    }
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(isLoading = false, error = e.message)
            }
        }
    }

    fun askSubjectMethod(subject: String) {
        val repo = aiRepository
        if (repo == null) {
            _uiState.value = _uiState.value.copy(error = "请先在设置中配置 AI API Key")
            return
        }

        viewModelScope.launch {
            chatRepo.saveMessage("user", "$subject 这门科目的学习方法和复习重点是什么？")
            _uiState.value = _uiState.value.copy(isLoading = true, error = null)

            try {
                val result = repo.chat(
                    userMessage = "$subject 这门科目的学习方法和复习重点是什么？请给出具体可执行的建议。",
                    history = _uiState.value.messages.map { it.role to it.content }.takeLast(10),
                    examDate = _uiState.value.examDate,
                    assistantName = _uiState.value.assistantName
                )
                result.fold(
                    onSuccess = { reply ->
                        chatRepo.saveMessage("assistant", reply)
                        _uiState.value = _uiState.value.copy(isLoading = false)
                    },
                    onFailure = { e ->
                        chatRepo.saveMessage("assistant", "抱歉，出错了：${e.message}")
                        _uiState.value = _uiState.value.copy(isLoading = false, error = e.message)
                    }
                )
            } catch (e: Exception) {
                chatRepo.saveMessage("assistant", "发生异常：${e.message}")
                _uiState.value = _uiState.value.copy(isLoading = false, error = e.message)
            }
        }
    }

    fun generateReviewReminder() {
        val repo = aiRepository
        if (repo == null) {
            _uiState.value = _uiState.value.copy(error = "请先在设置中配置 AI API Key")
            return
        }

        viewModelScope.launch {
            chatRepo.saveMessage("user", "根据艾宾浩斯遗忘曲线，帮我生成一份复习提醒计划")
            _uiState.value = _uiState.value.copy(isLoading = true, error = null)

            try {
                val prompt = PromptBuilder.buildReviewPrompt(
                    subjectStats = _uiState.value.subjectStats,
                    examDate = _uiState.value.examDate
                )
                val result = repo.chat(
                    userMessage = prompt,
                    history = emptyList(),
                    examDate = _uiState.value.examDate,
                    assistantName = _uiState.value.assistantName
                )
                result.fold(
                    onSuccess = { reply ->
                        chatRepo.saveMessage("assistant", reply)
                        _uiState.value = _uiState.value.copy(isLoading = false)
                    },
                    onFailure = { e ->
                        chatRepo.saveMessage("assistant", "生成复习提醒失败：${e.message}")
                        _uiState.value = _uiState.value.copy(isLoading = false, error = e.message)
                    }
                )
            } catch (e: Exception) {
                chatRepo.saveMessage("assistant", "生成复习提醒异常：${e.message}")
                _uiState.value = _uiState.value.copy(isLoading = false, error = e.message)
            }
        }
    }

    fun clearChat() {
        viewModelScope.launch {
            chatRepo.clearAll()
            _uiState.value = _uiState.value.copy(
                error = null,
                messages = emptyList(),
                historyQuestions = emptyList()
            )
        }
    }
}
