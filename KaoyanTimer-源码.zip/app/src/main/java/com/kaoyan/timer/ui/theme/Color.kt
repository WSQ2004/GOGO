package com.kaoyan.timer.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// 考研主题色
val Primary = Color(0xFF1A6B5C)
val PrimaryContainer = Color(0xFFA6F5E4)
val Secondary = Color(0xFFB8621B)
val SecondaryContainer = Color(0xFFFFDCC2)
val Tertiary = Color(0xFF4A6FA5)
val TertiaryContainer = Color(0xFFD3E4FD)

val BackgroundLight = Color(0xFFF5F5F0)
val SurfaceLight = Color(0xFFFFFFFF)
val OnSurfaceLight = Color(0xFF1A1C19)

val BackgroundDark = Color(0xFF1A1C19)
val SurfaceDark = Color(0xFF242822)
val OnSurfaceDark = Color(0xFFE2E3DD)

// 科目预设颜色
val SubjectColors = listOf(
    Color(0xFFE74C3C), // 红 - 政治
    Color(0xFF3498DB), // 蓝 - 英语
    Color(0xFF27AE60), // 绿 - 数学
    Color(0xFFF39C12), // 橙 - 专业课
    Color(0xFF9B59B6), // 紫
    Color(0xFF1ABC9C), // 青
    Color(0xFFE67E22), // 深橙
    Color(0xFF34495E), // 深蓝灰
    Color(0xFF16A085), // 深绿
    Color(0xFFC0392B)  // 深红
)
