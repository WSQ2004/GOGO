package com.kaoyan.timer.ui.screens.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.kaoyan.timer.util.TimeUtils

@Composable
fun SettingsScreen() {
    val viewModel: SettingsViewModel = viewModel()
    val state by viewModel.uiState.collectAsState()
    var showAddSubject by remember { mutableStateOf(false) }
    var newSubjectName by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        Text(
            text = "设置",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )

        // 考研设置
        SettingsSection(title = "考研设置") {
            SettingsItem(
                label = "考研日期",
                value = state.examDate,
                onClick = { /* 日期选择器 */ }
            )
            Divider()
            SettingsItem(
                label = "每日学习目标",
                value = TimeUtils.formatMinutes(state.dailyTarget)
            )
            // 目标滑块
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("2h", style = MaterialTheme.typography.bodySmall)
                androidx.compose.material3.Slider(
                    value = state.dailyTarget.toFloat(),
                    onValueChange = { viewModel.setDailyTarget(it.toInt()) },
                    valueRange = 60f..720f,
                    steps = 10,
                    modifier = Modifier.weight(1f)
                )
                Text("12h", style = MaterialTheme.typography.bodySmall)
            }
        }

        // 番茄钟设置
        SettingsSection(title = "番茄钟设置") {
            SettingsItem(label = "专注时长", value = "${state.pomodoroWork} 分钟")
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("15m", style = MaterialTheme.typography.bodySmall)
                androidx.compose.material3.Slider(
                    value = state.pomodoroWork.toFloat(),
                    onValueChange = { viewModel.setPomodoroWork(it.toInt()) },
                    valueRange = 15f..60f,
                    steps = 8,
                    modifier = Modifier.weight(1f)
                )
                Text("60m", style = MaterialTheme.typography.bodySmall)
            }
            Divider()
            SettingsItem(label = "休息时长", value = "${state.pomodoroBreak} 分钟")
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("3m", style = MaterialTheme.typography.bodySmall)
                androidx.compose.material3.Slider(
                    value = state.pomodoroBreak.toFloat(),
                    onValueChange = { viewModel.setPomodoroBreak(it.toInt()) },
                    valueRange = 3f..30f,
                    steps = 8,
                    modifier = Modifier.weight(1f)
                )
                Text("30m", style = MaterialTheme.typography.bodySmall)
            }
        }

        // 科目管理
        SettingsSection(title = "科目管理") {
            state.subjects.forEach { subject ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(12.dp)
                            .clip(CircleShape)
                            .background(Color(subject.color))
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = subject.name,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.weight(1f)
                    )
                    if (subject.isCustom) {
                        IconButton(onClick = { viewModel.deleteSubject(subject) }) {
                            Icon(
                                Icons.Default.Delete,
                                contentDescription = "删除",
                                tint = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            }
            Divider()
            TextButton(
                onClick = { showAddSubject = true },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("添加自定义科目")
            }
        }

        // AI 设置
        SettingsSection(title = "AI 助手配置") {
            OutlinedTextField(
                value = state.aiApiKey,
                onValueChange = { viewModel.setAiApiKey(it) },
                label = { Text("API Key") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                singleLine = true
            )
            OutlinedTextField(
                value = state.aiApiBase,
                onValueChange = { viewModel.setAiApiBase(it) },
                label = { Text("API Base URL") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                singleLine = true
            )
            OutlinedTextField(
                value = state.aiModel,
                onValueChange = { viewModel.setAiModel(it) },
                label = { Text("模型名称") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                singleLine = true
            )
            OutlinedTextField(
                value = state.aiAssistantName,
                onValueChange = { viewModel.setAiAssistantName(it) },
                label = { Text("AI 助手名字") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                singleLine = true
            )
            Text(
                text = "支持 OpenAI 兼容接口（如 OpenAI、DeepSeek、通义千问等），数据仅保存在本地",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
            )
        }

        // 主题设置
        SettingsSection(title = "外观") {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                ThemeOption("跟随系统", 0, state.themeMode) { viewModel.setThemeMode(0) }
                ThemeOption("浅色", 1, state.themeMode) { viewModel.setThemeMode(1) }
                ThemeOption("深色", 2, state.themeMode) { viewModel.setThemeMode(2) }
            }
        }

        // 关于
        SettingsSection(title = "关于") {
            SettingsItem(label = "版本", value = "1.0.0")
            Divider()
            SettingsItem(label = "考研时间记录", value = "AI 原生学习助手")
        }

        Spacer(modifier = Modifier.height(32.dp))
    }

    // 添加科目对话框
    if (showAddSubject) {
        AlertDialog(
            onDismissRequest = { showAddSubject = false },
            title = { Text("添加科目") },
            text = {
                OutlinedTextField(
                    value = newSubjectName,
                    onValueChange = { newSubjectName = it },
                    label = { Text("科目名称") },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (newSubjectName.isNotBlank()) {
                            viewModel.addSubject(newSubjectName.trim())
                            newSubjectName = ""
                            showAddSubject = false
                        }
                    }
                ) {
                    Text("添加")
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    newSubjectName = ""
                    showAddSubject = false
                }) {
                    Text("取消")
                }
            }
        )
    }
}

@Composable
fun SettingsSection(title: String, content: @Composable () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(start = 16.dp, top = 16.dp, bottom = 8.dp),
                color = MaterialTheme.colorScheme.primary
            )
            content()
            Spacer(modifier = Modifier.height(8.dp))
        }
    }
}

@Composable
fun SettingsItem(label: String, value: String, onClick: (() -> Unit)? = null) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = onClick != null) { onClick?.invoke() }
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.weight(1f)
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun ThemeOption(label: String, value: Int, selected: Int, onClick: () -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        RadioButton(
            selected = selected == value,
            onClick = onClick
        )
        Text(label, style = MaterialTheme.typography.bodyMedium)
    }
}
