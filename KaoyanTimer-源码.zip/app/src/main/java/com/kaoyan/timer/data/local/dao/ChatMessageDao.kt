package com.kaoyan.timer.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.kaoyan.timer.data.local.entity.ChatMessageEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ChatMessageDao {

    @Query("SELECT * FROM chat_messages ORDER BY timestamp ASC")
    fun getAllMessages(): Flow<List<ChatMessageEntity>>

    @Query("SELECT * FROM chat_messages ORDER BY timestamp DESC LIMIT :limit")
    fun getRecentMessages(limit: Int): Flow<List<ChatMessageEntity>>

    @Query("SELECT content FROM chat_messages WHERE role = 'user' GROUP BY content ORDER BY MAX(timestamp) DESC LIMIT :limit")
    suspend fun getRecentUserQuestions(limit: Int): List<String>

    @Insert
    suspend fun insert(message: ChatMessageEntity): Long

    @Query("DELETE FROM chat_messages")
    suspend fun clearAll()

    @Query("SELECT COUNT(*) FROM chat_messages")
    suspend fun getMessageCount(): Int
}
