package com.kaoyan.timer.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.kaoyan.timer.data.local.entity.StudyRecord
import kotlinx.coroutines.flow.Flow

@Dao
interface StudyRecordDao {
    @Query("SELECT * FROM study_records ORDER BY startTime DESC")
    fun getAllRecords(): Flow<List<StudyRecord>>

    @Query("SELECT * FROM study_records WHERE date = :date ORDER BY startTime DESC")
    fun getRecordsByDate(date: String): Flow<List<StudyRecord>>

    @Query("SELECT * FROM study_records WHERE date BETWEEN :startDate AND :endDate ORDER BY startTime DESC")
    fun getRecordsByDateRange(startDate: String, endDate: String): Flow<List<StudyRecord>>

    @Query("SELECT COALESCE(SUM(durationMinutes), 0) FROM study_records WHERE date = :date")
    fun getTotalMinutesByDate(date: String): Flow<Int>

    @Query("SELECT COALESCE(SUM(durationMinutes), 0) FROM study_records WHERE date BETWEEN :startDate AND :endDate")
    fun getTotalMinutesByDateRange(startDate: String, endDate: String): Flow<Int>

    @Query("SELECT subjectId, subjectName, subjectColor, COALESCE(SUM(durationMinutes), 0) as total FROM study_records WHERE date BETWEEN :startDate AND :endDate GROUP BY subjectId ORDER BY total DESC")
    fun getSubjectStatsByDateRange(startDate: String, endDate: String): Flow<List<SubjectStat>>

    @Query("SELECT date, COALESCE(SUM(durationMinutes), 0) as total FROM study_records WHERE date BETWEEN :startDate AND :endDate GROUP BY date ORDER BY date ASC")
    fun getDailyTotalsByDateRange(startDate: String, endDate: String): Flow<List<DailyTotal>>

    @Query("SELECT * FROM study_records WHERE id = :id")
    suspend fun getRecordById(id: Long): StudyRecord?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(record: StudyRecord): Long

    @Update
    suspend fun update(record: StudyRecord)

    @Delete
    suspend fun delete(record: StudyRecord)

    @Query("DELETE FROM study_records WHERE id = :id")
    suspend fun deleteById(id: Long)
}

data class SubjectStat(
    val subjectId: Long,
    val subjectName: String,
    val subjectColor: Long,
    val total: Int
)

data class DailyTotal(
    val date: String,
    val total: Int
)
