package com.kaoyan.timer

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.kaoyan.timer.ui.navigation.AppNavigation
import com.kaoyan.timer.ui.theme.KaoyanTimerTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            // 读取用户选择的主题模式：0=跟随系统 1=浅色 2=深色
            val themeMode by (application as KaoyanApp).settingsPref.themeMode.collectAsState(initial = 0)
            val darkTheme = when (themeMode) {
                1 -> false
                2 -> true
                else -> isSystemInDarkTheme()
            }

            KaoyanTimerTheme(
                darkTheme = darkTheme,
                // 仅"跟随系统"模式使用动态壁纸取色；手动选择浅/深色时用固定主题色
                dynamicColor = themeMode == 0
            ) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AppNavigation()
                }
            }
        }
    }
}
