package com.kaoyan.timer.ui.screens.timer

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.kaoyan.timer.KaoyanApp
import com.kaoyan.timer.ai.AIClient
import com.kaoyan.timer.ai.AIRepository
import com.kaoyan.timer.ai.PromptBuilder
import com.kaoyan.timer.data.local.entity.StudyRecord
import com.kaoyan.timer.data.local.entity.Subject
import com.kaoyan.timer.util.DateUtils
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

enum class TimerMode { STOPWATCH, POMODORO, MANUAL }
enum class TimerState { IDLE, RUNNING, PAUSED, FINISHED }

data class TimerUiState(
    val mode: TimerMode = TimerMode.STOPWATCH,
    val timerState: TimerState = TimerState.IDLE,
    val elapsedSeconds: Long = 0,
    val pomodoroWorkSeconds: Long = 25 * 60,
    val pomodoroBreakSeconds: Long = 5 * 60,
    val isBreakMode: Boolean = false,
    val selectedSubject: Subject? = null,
    val subjects: List<Subject> = emptyList(),
    val manualMinutes: Int = 30,
    val note: String = "",
    val aiSummary: String? = null,
    val isGeneratingSummary: Boolean = false
)

class TimerViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as KaoyanApp
    private val subjectRepo = app.subjectRepository
    private val recordRepo = app.studyRecordRepository
    private val settingsPref = app.settingsPref

    private val _uiState = MutableStateFlow(TimerUiState())
    val uiState: StateFlow<TimerUiState> = _uiState.asStateFlow()

    private var timerJob: Job? = null
    private var startTime: Long = 0

    init {
        viewModelScope.launch {
            subjectRepo.getAllSubjects().collect { subjects ->
                _uiState.value = _uiState.value.copy(
                    subjects = subjects,
                    selectedSubject = _uiState.value.selectedSubject ?: subjects.firstOrNull()
                )
            }
        }
        viewModelScope.launch {
            settingsPref.pomodoroWork.collect { work ->
                _uiState.value = _uiState.value.copy(pomodoroWorkSeconds = work * 60L)
            }
        }
        viewModelScope.launch {
            settingsPref.pomodoroBreak.collect { brk ->
                _uiState.value = _uiState.value.copy(pomodoroBreakSeconds = brk * 60L)
            }
        }
    }

    fun selectSubject(subject: Subject) {
        _uiState.value = _uiState.value.copy(selectedSubject = subject)
    }

    fun setMode(mode: TimerMode) {
        stopTimer()
        _uiState.value = _uiState.value.copy(
            mode = mode,
            timerState = TimerState.IDLE,
            elapsedSeconds = 0,
            isBreakMode = false
        )
    }

    fun setManualMinutes(minutes: Int) {
        _uiState.value = _uiState.value.copy(manualMinutes = minutes.coerceIn(1, 600))
    }

    fun setNote(note: String) {
        _uiState.value = _uiState.value.copy(note = note)
    }

    fun startTimer() {
        val state = _uiState.value
        if (state.selectedSubject == null) return

        startTime = System.currentTimeMillis() - state.elapsedSeconds * 1000
        _uiState.value = state.copy(timerState = TimerState.RUNNING)

        timerJob = viewModelScope.launch {
            while (true) {
                delay(1000)
                val current = _uiState.value
                val newElapsed = current.elapsedSeconds + 1

                if (current.mode == TimerMode.POMODORO) {
                    val target = if (current.isBreakMode) current.pomodoroBreakSeconds else current.pomodoroWorkSeconds
                    if (newElapsed >= target) {
                        _uiState.value = current.copy(
                            elapsedSeconds = target,
                            timerState = TimerState.FINISHED
                        )
                        // 自动切换到休息/工作
                        delay(500)
                        _uiState.value = _uiState.value.copy(
                            isBreakMode = !current.isBreakMode,
                            elapsedSeconds = 0,
                            timerState = TimerState.IDLE
                        )
                        break
                    }
                }

                _uiState.value = current.copy(elapsedSeconds = newElapsed)
            }
        }
    }

    fun pauseTimer() {
        timerJob?.cancel()
        _uiState.value = _uiState.value.copy(timerState = TimerState.PAUSED)
    }

    fun stopTimer() {
        timerJob?.cancel()
        timerJob = null
    }

    fun resetTimer() {
        stopTimer()
        _uiState.value = _uiState.value.copy(
            timerState = TimerState.IDLE,
            elapsedSeconds = 0,
            isBreakMode = false
        )
    }

    fun saveAndFinish(): Boolean {
        val state = _uiState.value
        val subject = state.selectedSubject ?: return false

        val duration = when (state.mode) {
            TimerMode.STOPWATCH -> ((state.elapsedSeconds + 30) / 60).toInt().coerceAtLeast(1)
            TimerMode.POMODORO -> if (state.isBreakMode) 0 else ((state.elapsedSeconds + 30) / 60).toInt().coerceAtLeast(1)
            TimerMode.MANUAL -> state.manualMinutes
        }

        if (duration <= 0) return false

        val now = System.currentTimeMillis()
        val recordStart = if (state.mode == TimerMode.MANUAL) now - duration * 60L else startTime
        val record = StudyRecord(
            subjectId = subject.id,
            subjectName = subject.name,
            subjectColor = subject.color,
            durationMinutes = duration,
            date = DateUtils.today(),
            startTime = recordStart,
            endTime = now,
            note = state.note,
            timerType = state.mode.name.lowercase()
        )

        viewModelScope.launch {
            val recordId = recordRepo.insert(record)
            generateAiSummary(recordId, subject.name, duration, state.note)
        }

        resetTimer()
        _uiState.value = _uiState.value.copy(note = "", aiSummary = null)
        return true
    }

    private suspend fun generateAiSummary(
        recordId: Long,
        subjectName: String,
        durationMinutes: Int,
        note: String
    ) {
        try {
            // 检查 AI 是否配置
            val apiKey = settingsPref.aiApiKey.first()
            if (apiKey.isBlank()) return

            _uiState.value = _uiState.value.copy(isGeneratingSummary = true)

            val apiBase = settingsPref.aiApiBase.first()
            val aiModel = settingsPref.aiModel.first()
            val examDate = settingsPref.examDate.first()
            val dailyTarget = settingsPref.dailyTarget.first()
            val todayMinutes = recordRepo.getTotalMinutesByDate(DateUtils.today()).first()

            val aiRepository = AIRepository(AIClient(apiKey, apiBase, aiModel))
            val prompt = PromptBuilder.buildStudySummaryPrompt(
                subjectName = subjectName,
                durationMinutes = durationMinutes,
                note = note,
                todayMinutes = todayMinutes,
                dailyTarget = dailyTarget,
                examDate = examDate
            )

            val result = aiRepository.chat(
                userMessage = prompt,
                history = emptyList(),
                examDate = examDate
            )

            result.fold(
                onSuccess = { summary ->
                    // 更新记录的 AI 总结
                    val updatedRecord = recordRepo.getRecordById(recordId)?.copy(aiSummary = summary)
                    if (updatedRecord != null) {
                        recordRepo.update(updatedRecord)
                    }
                    _uiState.value = _uiState.value.copy(
                        aiSummary = summary,
                        isGeneratingSummary = false
                    )
                },
                onFailure = {
                    _uiState.value = _uiState.value.copy(isGeneratingSummary = false)
                }
            )
        } catch (e: Exception) {
            Log.e("TimerViewModel", "AI summary generation failed", e)
            _uiState.value = _uiState.value.copy(isGeneratingSummary = false)
        }
    }

    fun getTotalSeconds(): Long {
        val state = _uiState.value
        return if (state.mode == TimerMode.POMODORO) {
            if (state.isBreakMode) state.pomodoroBreakSeconds else state.pomodoroWorkSeconds
        } else state.elapsedSeconds
    }
}
