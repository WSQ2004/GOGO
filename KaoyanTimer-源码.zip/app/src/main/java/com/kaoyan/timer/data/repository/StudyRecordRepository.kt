package com.kaoyan.timer.data.repository

import com.kaoyan.timer.data.local.dao.DailyTotal
import com.kaoyan.timer.data.local.dao.StudyRecordDao
import com.kaoyan.timer.data.local.dao.SubjectStat
import com.kaoyan.timer.data.local.entity.StudyRecord
import kotlinx.coroutines.flow.Flow

class StudyRecordRepository(private val studyRecordDao: StudyRecordDao) {
    fun getAllRecords(): Flow<List<StudyRecord>> = studyRecordDao.getAllRecords()

    fun getRecordsByDate(date: String): Flow<List<StudyRecord>> =
        studyRecordDao.getRecordsByDate(date)

    fun getRecordsByDateRange(startDate: String, endDate: String): Flow<List<StudyRecord>> =
        studyRecordDao.getRecordsByDateRange(startDate, endDate)

    fun getTotalMinutesByDate(date: String): Flow<Int> =
        studyRecordDao.getTotalMinutesByDate(date)

    fun getTotalMinutesByDateRange(startDate: String, endDate: String): Flow<Int> =
        studyRecordDao.getTotalMinutesByDateRange(startDate, endDate)

    fun getSubjectStatsByDateRange(startDate: String, endDate: String): Flow<List<SubjectStat>> =
        studyRecordDao.getSubjectStatsByDateRange(startDate, endDate)

    fun getDailyTotalsByDateRange(startDate: String, endDate: String): Flow<List<DailyTotal>> =
        studyRecordDao.getDailyTotalsByDateRange(startDate, endDate)

    suspend fun getRecordById(id: Long): StudyRecord? = studyRecordDao.getRecordById(id)

    suspend fun insert(record: StudyRecord): Long = studyRecordDao.insert(record)

    suspend fun update(record: StudyRecord) = studyRecordDao.update(record)

    suspend fun delete(record: StudyRecord) = studyRecordDao.delete(record)

    suspend fun deleteById(id: Long) = studyRecordDao.deleteById(id)
}
