package com.kaoyan.timer.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.kaoyan.timer.ui.screens.ai.AIScreen
import com.kaoyan.timer.ui.screens.home.HomeScreen
import com.kaoyan.timer.ui.screens.settings.SettingsScreen
import com.kaoyan.timer.ui.screens.stats.StatsScreen
import com.kaoyan.timer.ui.screens.timer.TimerScreen

sealed class Screen(val route: String, val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    data object Home : Screen("home", "首页", Icons.Default.Home)
    data object Timer : Screen("timer", "计时", Icons.Default.Timer)
    data object Stats : Screen("stats", "统计", Icons.Default.Analytics)
    data object AI : Screen("ai", "AI助手", Icons.Default.Psychology)
    data object Settings : Screen("settings", "设置", Icons.Default.Settings)
}

val bottomScreens = listOf(Screen.Home, Screen.Timer, Screen.Stats, Screen.AI, Screen.Settings)

@Composable
fun AppNavigation() {
    val navController = rememberNavController()

    Scaffold(
        bottomBar = {
            NavigationBar {
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentDestination = navBackStackEntry?.destination
                bottomScreens.forEach { screen ->
                    NavigationBarItem(
                        icon = { Icon(screen.icon, contentDescription = screen.title) },
                        label = { Text(screen.title) },
                        selected = currentDestination?.hierarchy?.any { it.route == screen.route } == true,
                        onClick = {
                            navController.navigate(screen.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Home.route) { HomeScreen(navController) }
            composable(Screen.Timer.route) { TimerScreen() }
            composable(Screen.Stats.route) { StatsScreen() }
            composable(Screen.AI.route) { AIScreen() }
            composable(Screen.Settings.route) { SettingsScreen() }
        }
    }
}
