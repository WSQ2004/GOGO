package com.kaoyan.timer.util

import java.util.concurrent.TimeUnit

object TimeUtils {

    fun formatMinutes(minutes: Int): String {
        val hours = minutes / 60
        val mins = minutes % 60
        return if (hours > 0) "${hours}小时${mins}分钟" else "${mins}分钟"
    }

    fun formatMinutesShort(minutes: Int): String {
        val hours = minutes / 60
        val mins = minutes % 60
        return if (hours > 0) String.format("%dh %02dm", hours, mins) else "${mins}m"
    }

    fun formatSeconds(totalSeconds: Long): String {
        val hours = TimeUnit.SECONDS.toHours(totalSeconds)
        val minutes = TimeUnit.SECONDS.toMinutes(totalSeconds) % 60
        val seconds = totalSeconds % 60
        return if (hours > 0) {
            String.format("%02d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format("%02d:%02d", minutes, seconds)
        }
    }

    fun formatHours(minutes: Int): String {
        return String.format("%.1f", minutes / 60.0)
    }

    fun getPercentage(part: Int, total: Int): Float {
        return if (total == 0) 0f else (part.toFloat() / total * 100)
    }
}
