package com.kaoyan.timer.ui.screens.home

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.kaoyan.timer.KaoyanApp
import com.kaoyan.timer.data.local.entity.StudyRecord
import com.kaoyan.timer.data.local.entity.Subject
import com.kaoyan.timer.util.DateUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

data class HomeUiState(
    val examDate: String = "2026-12-21",
    val daysLeft: Long = 0,
    val todayMinutes: Int = 0,
    val dailyTarget: Int = 480,
    val subjects: List<Subject> = emptyList(),
    val todayRecords: List<StudyRecord> = emptyList(),
    val subjectMinutes: Map<String, Int> = emptyMap(),
    val streakDays: Int = 0
)

class HomeViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as KaoyanApp
    private val subjectRepo = app.subjectRepository
    private val recordRepo = app.studyRecordRepository
    private val settingsPref = app.settingsPref

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            val today = DateUtils.today()
            combine(
                settingsPref.examDate,
                settingsPref.dailyTarget,
                subjectRepo.getAllSubjects(),
                recordRepo.getRecordsByDate(today),
                recordRepo.getTotalMinutesByDate(today)
            ) { examDate, target, subjects, records, total ->
                val subjectMap = records.groupBy { it.subjectName }
                    .mapValues { it.value.sumOf { r -> r.durationMinutes } }
                HomeUiState(
                    examDate = examDate,
                    daysLeft = DateUtils.daysUntil(examDate),
                    todayMinutes = total,
                    dailyTarget = target,
                    subjects = subjects,
                    todayRecords = records,
                    subjectMinutes = subjectMap
                )
            }.collect { _uiState.value = it }
        }
    }

    fun ensureDefaultSubjects() {
        viewModelScope.launch {
            if (subjectRepo.getCount() == 0) {
                val defaults = listOf(
                    Subject(name = "政治", color = 0xFFE74C3C, icon = "📕"),
                    Subject(name = "英语", color = 0xFF3498DB, icon = "📘"),
                    Subject(name = "数学", color = 0xFF27AE60, icon = "📗"),
                    Subject(name = "专业课", color = 0xFFF39C12, icon = "📙")
                )
                defaults.forEach { subjectRepo.insert(it) }
            }
        }
    }
}
