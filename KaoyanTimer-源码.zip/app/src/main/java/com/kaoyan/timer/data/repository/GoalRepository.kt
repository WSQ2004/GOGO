package com.kaoyan.timer.data.repository

import com.kaoyan.timer.data.local.dao.GoalDao
import com.kaoyan.timer.data.local.entity.DailyGoal
import kotlinx.coroutines.flow.Flow

class GoalRepository(private val goalDao: GoalDao) {
    fun getGoalByDate(date: String): Flow<DailyGoal?> = goalDao.getGoalByDate(date)

    suspend fun upsert(goal: DailyGoal) = goalDao.upsert(goal)

    suspend fun updateCompleted(date: String, minutes: Int) =
        goalDao.updateCompleted(date, minutes)
}
