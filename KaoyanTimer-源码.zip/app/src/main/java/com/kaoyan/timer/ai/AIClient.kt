package com.kaoyan.timer.ai

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class AIClient(
    private val apiKey: String,
    private val apiBase: String,
    private val model: String
) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun chat(
        systemPrompt: String,
        userMessage: String,
        history: List<Pair<String, String>> = emptyList()
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val messages = JSONArray()
            messages.put(JSONObject().put("role", "system").put("content", systemPrompt))
            history.forEach { (role, content) ->
                messages.put(JSONObject().put("role", role).put("content", content))
            }
            messages.put(JSONObject().put("role", "user").put("content", userMessage))

            val body = JSONObject()
                .put("model", model)
                .put("messages", messages)
                .put("temperature", 0.7)
                .put("max_tokens", 1024)

            // 清理 base url，避免双斜杠
            val base = apiBase.trimEnd('/')
            val url = "$base/chat/completions"

            Log.d("AIClient", "Request URL: $url, model: $model, key prefix: ${apiKey.take(7)}...")

            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $apiKey")
                .addHeader("Content-Type", "application/json")
                .post(body.toString().toRequestBody(jsonMediaType))
                .build()

            client.newCall(request).execute().use { response ->
                val responseBody = response.body?.string() ?: ""
                Log.d("AIClient", "Response code: ${response.code}, body: ${responseBody.take(500)}")

                if (!response.isSuccessful) {
                    // 尝试解析 API 返回的错误信息
                    val errorMsg = try {
                        val errorJson = JSONObject(responseBody)
                        errorJson.optJSONObject("error")?.optString("message")
                            ?: errorJson.optString("message")
                            ?: responseBody.take(200)
                    } catch (_: Exception) {
                        responseBody.take(200)
                    }
                    return@withContext Result.failure(Exception("请求失败 (${response.code}): $errorMsg"))
                }

                if (responseBody.isBlank()) {
                    return@withContext Result.failure(Exception("API 返回空响应"))
                }

                val json = JSONObject(responseBody)
                val choices = json.optJSONArray("choices")
                if (choices == null || choices.length() == 0) {
                    return@withContext Result.failure(Exception("API 返回格式异常: $responseBody"))
                }

                val firstChoice = choices.getJSONObject(0)
                val message = firstChoice.optJSONObject("message")
                val content = message?.optString("content", "") ?: ""

                if (content.isBlank()) {
                    return@withContext Result.failure(Exception("API 返回内容为空"))
                }

                Result.success(content)
            }
        } catch (e: Exception) {
            Log.e("AIClient", "Chat error", e)
            Result.failure(Exception("网络或解析错误: ${e.message ?: "未知错误"}"))
        }
    }

    fun isConfigured(): Boolean = apiKey.isNotBlank()
}
