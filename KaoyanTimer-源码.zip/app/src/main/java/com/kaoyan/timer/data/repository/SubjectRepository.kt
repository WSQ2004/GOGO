package com.kaoyan.timer.data.repository

import com.kaoyan.timer.data.local.dao.SubjectDao
import com.kaoyan.timer.data.local.entity.Subject
import kotlinx.coroutines.flow.Flow

class SubjectRepository(private val subjectDao: SubjectDao) {
    fun getAllSubjects(): Flow<List<Subject>> = subjectDao.getAllSubjects()

    suspend fun getSubjectById(id: Long): Subject? = subjectDao.getSubjectById(id)

    suspend fun insert(subject: Subject): Long = subjectDao.insert(subject)

    suspend fun update(subject: Subject) = subjectDao.update(subject)

    suspend fun delete(subject: Subject) = subjectDao.delete(subject)

    suspend fun getCount(): Int = subjectDao.getCount()
}
