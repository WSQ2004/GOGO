package com.kaoyan.timer.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "daily_goals")
data class DailyGoal(
    @PrimaryKey val date: String, // yyyy-MM-dd
    val targetMinutes: Int,
    val completedMinutes: Int = 0
)
