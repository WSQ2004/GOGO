package com.kaoyan.timer.ui.screens.timer

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.kaoyan.timer.ui.components.SubjectChip
import com.kaoyan.timer.ui.components.TimerCircle
import com.kaoyan.timer.util.TimeUtils

@Composable
fun TimerScreen() {
    val viewModel: TimerViewModel = viewModel()
    val state by viewModel.uiState.collectAsState()
    var showSaveDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // 模式切换
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            TimerModeTab(
                text = "正计时",
                selected = state.mode == TimerMode.STOPWATCH,
                onClick = { viewModel.setMode(TimerMode.STOPWATCH) }
            )
            TimerModeTab(
                text = "番茄钟",
                selected = state.mode == TimerMode.POMODORO,
                onClick = { viewModel.setMode(TimerMode.POMODORO) }
            )
            TimerModeTab(
                text = "手动录入",
                selected = state.mode == TimerMode.MANUAL,
                onClick = { viewModel.setMode(TimerMode.MANUAL) }
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // 科目选择
        if (state.mode != TimerMode.MANUAL) {
            Text(
                text = "选择科目",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.align(Alignment.Start)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                state.subjects.forEach { subject ->
                    SubjectChip(
                        name = subject.name,
                        color = subject.color,
                        selected = state.selectedSubject?.id == subject.id,
                        onClick = { viewModel.selectSubject(subject) }
                    )
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }

        // 计时器显示
        if (state.mode == TimerMode.MANUAL) {
            ManualInputSection(
                minutes = state.manualMinutes,
                onMinutesChange = { viewModel.setManualMinutes(it) },
                subjects = state.subjects,
                selectedSubject = state.selectedSubject,
                onSubjectSelect = { viewModel.selectSubject(it) },
                note = state.note,
                onNoteChange = { viewModel.setNote(it) }
            )
        } else {
            val totalSeconds = viewModel.getTotalSeconds()
            val progress = if (state.mode == TimerMode.POMODORO) {
                if (totalSeconds > 0) state.elapsedSeconds.toFloat() / totalSeconds else 0f
            } else 0f

            val displayText = if (state.mode == TimerMode.POMODORO) {
                val remaining = totalSeconds - state.elapsedSeconds
                TimeUtils.formatSeconds(remaining)
            } else {
                TimeUtils.formatSeconds(state.elapsedSeconds)
            }

            val label = when {
                state.mode == TimerMode.POMODORO && state.isBreakMode -> "休息中"
                state.mode == TimerMode.POMODORO -> "专注中"
                else -> "学习时长"
            }

            TimerCircle(
                progress = if (state.mode == TimerMode.POMODORO) progress else 0.75f,
                timeText = displayText,
                label = label,
                size = 260.dp,
                progressColor = if (state.isBreakMode) MaterialTheme.colorScheme.tertiary
                else MaterialTheme.colorScheme.primary
            )

            Spacer(modifier = Modifier.height(24.dp))

            // 控制按钮
            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (state.timerState == TimerState.RUNNING) {
                    ControlButton(
                        icon = Icons.Default.Pause,
                        text = "暂停",
                        onClick = { viewModel.pauseTimer() },
                        color = MaterialTheme.colorScheme.secondary
                    )
                } else {
                    ControlButton(
                        icon = Icons.Default.PlayArrow,
                        text = "开始",
                        onClick = { viewModel.startTimer() },
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                ControlButton(
                    icon = Icons.Default.Replay,
                    text = "重置",
                    onClick = { viewModel.resetTimer() },
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    isOutline = true
                )

                if (state.elapsedSeconds > 0 || state.timerState == TimerState.PAUSED) {
                    ControlButton(
                        icon = Icons.Default.Stop,
                        text = "结束保存",
                        onClick = {
                            if (viewModel.saveAndFinish()) {
                                showSaveDialog = true
                            }
                        },
                        color = MaterialTheme.colorScheme.error
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(32.dp))
    }

    if (showSaveDialog) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = {
                if (!state.isGeneratingSummary) showSaveDialog = false
            },
            title = {
                if (state.aiSummary != null) {
                    Text("AI 学习反馈")
                } else {
                    Text("保存成功")
                }
            },
            text = {
                when {
                    state.isGeneratingSummary -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(12.dp))
                            Text("AI 正在生成学习反馈...")
                        }
                    }
                    state.aiSummary != null -> {
                        Text(
                            text = state.aiSummary!!,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                    else -> {
                        Text("学习记录已保存，继续加油！")
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = { showSaveDialog = false },
                    enabled = !state.isGeneratingSummary
                ) {
                    Text("好的")
                }
            }
        )
    }
}

@Composable
fun TimerModeTab(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp, horizontal = 16.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            color = if (selected) MaterialTheme.colorScheme.primary
            else MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun ControlButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    text: String,
    onClick: () -> Unit,
    color: Color,
    isOutline: Boolean = false
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(64.dp)
                .clip(CircleShape)
                .then(
                    if (isOutline) Modifier.border(2.dp, color, CircleShape)
                    else Modifier.background(color)
                )
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                icon,
                contentDescription = text,
                tint = if (isOutline) color else Color.White,
                modifier = Modifier.size(32.dp)
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = text,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun ManualInputSection(
    minutes: Int,
    onMinutesChange: (Int) -> Unit,
    subjects: List<com.kaoyan.timer.data.local.entity.Subject>,
    selectedSubject: com.kaoyan.timer.data.local.entity.Subject?,
    onSubjectSelect: (com.kaoyan.timer.data.local.entity.Subject) -> Unit,
    note: String,
    onNoteChange: (String) -> Unit
) {
    var showSaveDialog by remember { mutableStateOf(false) }
    val viewModel: TimerViewModel = viewModel()

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "手动录入学习时长",
            style = MaterialTheme.typography.titleMedium
        )
        Spacer(modifier = Modifier.height(24.dp))

        // 科目选择
        Text(
            text = "选择科目",
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.align(Alignment.Start)
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            subjects.forEach { subject ->
                SubjectChip(
                    name = subject.name,
                    color = subject.color,
                    selected = selectedSubject?.id == subject.id,
                    onClick = { onSubjectSelect(subject) }
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // 时长输入
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "学习时长",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { onMinutesChange(minutes - 5) }) {
                        Text("-5", fontSize = 20.sp)
                    }
                    Text(
                        text = "$minutes",
                        style = MaterialTheme.typography.headlineLarge,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.width(100.dp),
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "分钟",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    TextButton(onClick = { onMinutesChange(minutes + 5) }) {
                        Text("+5", fontSize = 20.sp)
                    }
                }
                // 快捷按钮
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(15, 30, 60, 90, 120).forEach { m ->
                        FilledTonalButton(
                            onClick = { onMinutesChange(m) },
                            modifier = Modifier.height(36.dp)
                        ) {
                            Text("${m}分", fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 备注
        OutlinedTextField(
            value = note,
            onValueChange = onNoteChange,
            label = { Text("备注（可选）") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = {
                if (viewModel.saveAndFinish()) {
                    showSaveDialog = true
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primary
            )
        ) {
            Text("保存记录", fontWeight = FontWeight.Bold)
        }
    }

    if (showSaveDialog) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showSaveDialog = false },
            title = { Text("保存成功") },
            text = { Text("学习记录已保存！") },
            confirmButton = {
                TextButton(onClick = { showSaveDialog = false }) {
                    Text("好的")
                }
            }
        )
    }
}
