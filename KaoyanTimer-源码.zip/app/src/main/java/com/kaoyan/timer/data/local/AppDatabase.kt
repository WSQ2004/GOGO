package com.kaoyan.timer.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.kaoyan.timer.data.local.dao.ChatMessageDao
import com.kaoyan.timer.data.local.dao.GoalDao
import com.kaoyan.timer.data.local.dao.StudyRecordDao
import com.kaoyan.timer.data.local.dao.SubjectDao
import com.kaoyan.timer.data.local.entity.ChatMessageEntity
import com.kaoyan.timer.data.local.entity.DailyGoal
import com.kaoyan.timer.data.local.entity.StudyRecord
import com.kaoyan.timer.data.local.entity.Subject

@Database(
    entities = [Subject::class, StudyRecord::class, DailyGoal::class, ChatMessageEntity::class],
    version = 3,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun subjectDao(): SubjectDao
    abstract fun studyRecordDao(): StudyRecordDao
    abstract fun goalDao(): GoalDao
    abstract fun chatMessageDao(): ChatMessageDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "kaoyan_timer_db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
