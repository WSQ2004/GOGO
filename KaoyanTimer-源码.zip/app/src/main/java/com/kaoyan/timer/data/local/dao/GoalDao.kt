package com.kaoyan.timer.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.kaoyan.timer.data.local.entity.DailyGoal
import kotlinx.coroutines.flow.Flow

@Dao
interface GoalDao {
    @Query("SELECT * FROM daily_goals WHERE date = :date")
    fun getGoalByDate(date: String): Flow<DailyGoal?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(goal: DailyGoal)

    @Query("UPDATE daily_goals SET completedMinutes = :minutes WHERE date = :date")
    suspend fun updateCompleted(date: String, minutes: Int)
}
