package com.kaoyan.timer

import android.app.Application
import com.kaoyan.timer.data.local.AppDatabase
import com.kaoyan.timer.data.pref.SettingsPref
import com.kaoyan.timer.data.repository.ChatRepository
import com.kaoyan.timer.data.repository.GoalRepository
import com.kaoyan.timer.data.repository.StudyRecordRepository
import com.kaoyan.timer.data.repository.SubjectRepository

class KaoyanApp : Application() {
    val database by lazy { AppDatabase.getDatabase(this) }
    val subjectRepository by lazy { SubjectRepository(database.subjectDao()) }
    val studyRecordRepository by lazy { StudyRecordRepository(database.studyRecordDao()) }
    val goalRepository by lazy { GoalRepository(database.goalDao()) }
    val chatRepository by lazy { ChatRepository(database.chatMessageDao()) }
    val settingsPref by lazy { SettingsPref(this) }

    companion object {
        lateinit var instance: KaoyanApp
            private set
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
    }
}
