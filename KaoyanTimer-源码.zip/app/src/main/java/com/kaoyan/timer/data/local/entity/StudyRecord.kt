package com.kaoyan.timer.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "study_records",
    foreignKeys = [
        ForeignKey(
            entity = Subject::class,
            parentColumns = ["id"],
            childColumns = ["subjectId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("subjectId"), Index("date")]
)
data class StudyRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subjectId: Long,
    val subjectName: String,
    val subjectColor: Long,
    val durationMinutes: Int,
    val date: String, // yyyy-MM-dd
    val startTime: Long,
    val endTime: Long,
    val note: String = "",
    val timerType: String = "stopwatch", // stopwatch / pomodoro / manual
    val aiSummary: String = ""
)
