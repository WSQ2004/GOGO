package com.kaoyan.timer.data.repository

import com.kaoyan.timer.data.local.dao.ChatMessageDao
import com.kaoyan.timer.data.local.entity.ChatMessageEntity
import com.kaoyan.timer.ui.screens.ai.ChatMessage
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class ChatRepository(private val chatMessageDao: ChatMessageDao) {

    val allMessages: Flow<List<ChatMessage>> = chatMessageDao.getAllMessages()
        .map { entities ->
            entities.map { it.toChatMessage() }
        }

    suspend fun saveMessage(role: String, content: String): Long {
        return chatMessageDao.insert(
            ChatMessageEntity(role = role, content = content)
        )
    }

    suspend fun getRecentUserQuestions(limit: Int = 10): List<String> {
        return chatMessageDao.getRecentUserQuestions(limit)
    }

    suspend fun clearAll() {
        chatMessageDao.clearAll()
    }

    private fun ChatMessageEntity.toChatMessage(): ChatMessage {
        return ChatMessage(role = role, content = content, timestamp = timestamp)
    }
}
