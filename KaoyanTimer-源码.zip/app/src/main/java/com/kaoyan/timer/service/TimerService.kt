package com.kaoyan.timer.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.CountDownTimer
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.kaoyan.timer.MainActivity
import com.kaoyan.timer.R
import com.kaoyan.timer.util.TimeUtils

class TimerService : Service() {

    companion object {
        const val CHANNEL_ID = "study_timer_channel"
        const val NOTIFICATION_ID = 1001
        const val ACTION_START = "action_start"
        const val ACTION_PAUSE = "action_pause"
        const val ACTION_STOP = "action_stop"
        const val EXTRA_DURATION = "extra_duration"
        const val EXTRA_SUBJECT = "extra_subject"

        fun start(context: Context, subjectName: String, durationSeconds: Long) {
            val intent = Intent(context, TimerService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_SUBJECT, subjectName)
                putExtra(EXTRA_DURATION, durationSeconds)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, TimerService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }

    private var countDownTimer: CountDownTimer? = null
    private var remainingSeconds: Long = 0
    private var subjectName: String = ""
    private var isPomodoro: Boolean = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                subjectName = intent.getStringExtra(EXTRA_SUBJECT) ?: "学习"
                remainingSeconds = intent.getLongExtra(EXTRA_DURATION, 0)
                isPomodoro = remainingSeconds > 0
                startForeground(NOTIFICATION_ID, buildNotification("正在学习：$subjectName", "00:00"))
                if (isPomodoro) {
                    startCountDown(remainingSeconds)
                }
            }
            ACTION_PAUSE -> {
                countDownTimer?.cancel()
            }
            ACTION_STOP -> {
                countDownTimer?.cancel()
                stopSelf()
            }
        }
        return START_STICKY
    }

    private fun startCountDown(totalSeconds: Long) {
        countDownTimer = object : CountDownTimer(totalSeconds * 1000, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                remainingSeconds = millisUntilFinished / 1000
                updateNotification(
                    "番茄钟：$subjectName",
                    TimeUtils.formatSeconds(remainingSeconds)
                )
            }

            override fun onFinish() {
                updateNotification("学习完成！", "$subjectName 已完成")
                stopSelf()
            }
        }.start()
    }

    private fun buildNotification(title: String, content: String): Notification {
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(content)
            .setSmallIcon(R.drawable.ic_timer)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun updateNotification(title: String, content: String) {
        val notification = buildNotification(title, content)
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, notification)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "学习计时",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "考研学习计时通知"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        countDownTimer?.cancel()
        super.onDestroy()
    }
}
