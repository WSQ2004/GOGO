package com.kaoyan.timer.data.pref

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

class SettingsPref(private val context: Context) {

    companion object {
        private val KEY_EXAM_DATE = stringPreferencesKey("exam_date")
        private val KEY_DAILY_TARGET = intPreferencesKey("daily_target_minutes")
        private val KEY_POMODORO_WORK = intPreferencesKey("pomodoro_work_minutes")
        private val KEY_POMODORO_BREAK = intPreferencesKey("pomodoro_break_minutes")
        private val KEY_AI_API_KEY = stringPreferencesKey("ai_api_key")
        private val KEY_AI_API_BASE = stringPreferencesKey("ai_api_base")
        private val KEY_AI_MODEL = stringPreferencesKey("ai_model")
        private val KEY_AI_ASSISTANT_NAME = stringPreferencesKey("ai_assistant_name")
        private val KEY_THEME_MODE = intPreferencesKey("theme_mode") // 0=system,1=light,2=dark
        private val KEY_REMINDER_ENABLED = intPreferencesKey("reminder_enabled")
        private val KEY_REMINDER_TIME = stringPreferencesKey("reminder_time")
    }

    val examDate: Flow<String> = context.dataStore.data.map { it[KEY_EXAM_DATE] ?: "2026-12-21" }
    val dailyTarget: Flow<Int> = context.dataStore.data.map { it[KEY_DAILY_TARGET] ?: 480 }
    val pomodoroWork: Flow<Int> = context.dataStore.data.map { it[KEY_POMODORO_WORK] ?: 25 }
    val pomodoroBreak: Flow<Int> = context.dataStore.data.map { it[KEY_POMODORO_BREAK] ?: 5 }
    val aiApiKey: Flow<String> = context.dataStore.data.map { it[KEY_AI_API_KEY] ?: "" }
    val aiApiBase: Flow<String> = context.dataStore.data.map { it[KEY_AI_API_BASE] ?: "https://api.openai.com/v1" }
    val aiModel: Flow<String> = context.dataStore.data.map { it[KEY_AI_MODEL] ?: "gpt-3.5-turbo" }
    val aiAssistantName: Flow<String> = context.dataStore.data.map { it[KEY_AI_ASSISTANT_NAME] ?: "小研" }
    val themeMode: Flow<Int> = context.dataStore.data.map { it[KEY_THEME_MODE] ?: 0 }
    val reminderEnabled: Flow<Int> = context.dataStore.data.map { it[KEY_REMINDER_ENABLED] ?: 0 }
    val reminderTime: Flow<String> = context.dataStore.data.map { it[KEY_REMINDER_TIME] ?: "08:00" }

    suspend fun setExamDate(date: String) { context.dataStore.edit { it[KEY_EXAM_DATE] = date } }
    suspend fun setDailyTarget(minutes: Int) { context.dataStore.edit { it[KEY_DAILY_TARGET] = minutes } }
    suspend fun setPomodoroWork(minutes: Int) { context.dataStore.edit { it[KEY_POMODORO_WORK] = minutes } }
    suspend fun setPomodoroBreak(minutes: Int) { context.dataStore.edit { it[KEY_POMODORO_BREAK] = minutes } }
    suspend fun setAiApiKey(key: String) { context.dataStore.edit { it[KEY_AI_API_KEY] = key } }
    suspend fun setAiApiBase(base: String) { context.dataStore.edit { it[KEY_AI_API_BASE] = base } }
    suspend fun setAiModel(model: String) { context.dataStore.edit { it[KEY_AI_MODEL] = model } }
    suspend fun setAiAssistantName(name: String) { context.dataStore.edit { it[KEY_AI_ASSISTANT_NAME] = name } }
    suspend fun setThemeMode(mode: Int) { context.dataStore.edit { it[KEY_THEME_MODE] = mode } }
    suspend fun setReminderEnabled(enabled: Int) { context.dataStore.edit { it[KEY_REMINDER_ENABLED] = enabled } }
    suspend fun setReminderTime(time: String) { context.dataStore.edit { it[KEY_REMINDER_TIME] = time } }
}
