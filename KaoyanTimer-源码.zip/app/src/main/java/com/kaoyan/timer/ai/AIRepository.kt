package com.kaoyan.timer.ai

import com.kaoyan.timer.data.local.dao.DailyTotal
import com.kaoyan.timer.data.local.dao.SubjectStat

class AIRepository(private val aiClient: AIClient) {

    suspend fun generateAnalysis(
        subjectStats: List<SubjectStat>,
        dailyTotals: List<DailyTotal>,
        totalMinutes: Int,
        dailyTarget: Int,
        examDate: String
    ): Result<String> {
        val prompt = PromptBuilder.buildAnalysisPrompt(
            subjectStats, dailyTotals, totalMinutes, dailyTarget, examDate
        )
        return aiClient.chat("你是专业的考研学习分析顾问。", prompt)
    }

    suspend fun chat(
        userMessage: String,
        history: List<Pair<String, String>>,
        examDate: String,
        assistantName: String = "小研"
    ): Result<String> {
        val systemPrompt = PromptBuilder.buildChatSystemPrompt(examDate, assistantName)
        return aiClient.chat(systemPrompt, userMessage, history)
    }

    suspend fun generateReminder(
        todayMinutes: Int,
        dailyTarget: Int,
        subjectStats: List<SubjectStat>,
        examDate: String
    ): Result<String> {
        val prompt = PromptBuilder.buildReminderPrompt(
            todayMinutes, dailyTarget, subjectStats, examDate
        )
        return aiClient.chat("你是考研学习提醒助手。", prompt)
    }

    fun isConfigured(): Boolean = aiClient.isConfigured()
}
