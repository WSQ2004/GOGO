# Add project specific ProGuard rules here.
-keep class com.kaoyan.timer.data.local.entity.** { *; }
