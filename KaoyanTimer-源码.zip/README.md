# 考研计时 - AI 原生安卓 App

一款专为考研党设计的时间记录与 AI 学习分析应用，基于 **Kotlin + Jetpack Compose** 原生开发。

## 功能特性

### 核心功能
- **考研倒计时**：首页醒目展示距离考研的天数
- **三种计时模式**：
  - 正计时：自由记录学习时长
  - 番茄钟：专注/休息循环，可自定义时长
  - 手动录入：快速补录学习记录
- **科目管理**：默认政治/英语/数学/专业课，支持自定义添加删除
- **学习目标**：可设置每日学习时长目标（2-12小时）
- **数据统计**：今日/本周/本月多维度统计，包含每日趋势柱状图和各科占比饼图

### AI 功能（需配置 API Key）
- **AI 学习分析**：基于近 7 天数据生成个性化分析报告，包含总体评价、亮点、问题、建议
- **AI 对话助手**：随时咨询考研规划、学习方法、心态调整等问题
- **智能提醒**：根据学习进度生成个性化提醒文案

### 其他
- 纯本地数据存储（Room + DataStore），无需联网也能使用基础功能
- 前台服务通知，计时不中断
- 支持浅色/深色/跟随系统主题
- Material You 动态配色

## 技术栈

| 模块 | 技术 |
|------|------|
| 语言 | Kotlin |
| UI | Jetpack Compose + Material 3 |
| 架构 | MVVM + Repository |
| 数据库 | Room |
| 偏好存储 | DataStore Preferences |
| 异步 | Kotlin Coroutines + Flow |
| 网络 | OkHttp |
| AI | OpenAI 兼容 API（支持 DeepSeek、通义千问等） |
| 最低 SDK | API 26 (Android 8.0) |
| 目标 SDK | API 34 (Android 14) |

## 项目结构

```
app/src/main/java/com/kaoyan/timer/
├── KaoyanApp.kt              # Application 入口
├── MainActivity.kt           # 主 Activity
├── ai/                       # AI 接入层
│   ├── AIClient.kt           # API 客户端
│   ├── AIRepository.kt       # AI 仓库
│   └── PromptBuilder.kt      # 提示词构建
├── data/
│   ├── local/                # Room 数据库
│   │   ├── AppDatabase.kt
│   │   ├── dao/              # 数据访问对象
│   │   └── entity/           # 实体类
│   ├── pref/                 # DataStore 偏好
│   └── repository/           # 数据仓库
├── service/
│   └── TimerService.kt       # 前台计时服务
├── ui/
│   ├── theme/                # 主题配色
│   ├── navigation/           # 导航
│   ├── components/           # 通用组件
│   └── screens/              # 业务页面
│       ├── home/             # 首页
│       ├── timer/            # 计时页
│       ├── stats/            # 统计页
│       ├── ai/               # AI 助手页
│       └── settings/         # 设置页
└── util/                     # 工具类
```

## 快速开始

### 环境要求
- Android Studio Hedgehog (2023.1.1) 或更高版本
- JDK 17
- Android SDK 34

### 编译运行
1. 用 Android Studio 打开项目根目录 `KaoyanTimer/`
2. 等待 Gradle 同步完成（首次会自动下载依赖）
3. 连接 Android 设备或启动模拟器（API 26+）
4. 点击 Run 按钮编译运行

### 配置 AI 功能
1. 打开 App → 底部「设置」
2. 找到「AI 助手配置」
3. 填入以下信息：
   - **API Key**：你的大模型 API 密钥
   - **API Base URL**：接口地址
     - OpenAI: `https://api.openai.com/v1`
     - DeepSeek: `https://api.deepseek.com/v1`
     - 通义千问: `https://dashscope.aliyuncs.com/compatible-mode/v1`
   - **模型名称**：如 `gpt-3.5-turbo`、`deepseek-chat`、`qwen-turbo` 等
4. 保存后即可使用 AI 分析和对话功能

> 注意：API Key 仅保存在本地 DataStore 中，不会上传到任何服务器。

## 默认配置

- 考研日期：2026-12-21（可在设置中修改）
- 每日目标：480 分钟（8 小时）
- 番茄钟：25 分钟专注 + 5 分钟休息
- 默认科目：政治、英语、数学、专业课

## 数据说明

所有学习数据均存储在设备本地的 Room 数据库中，卸载 App 会清除数据。建议定期备份。

## License

MIT License
