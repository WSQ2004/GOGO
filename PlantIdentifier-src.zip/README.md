# 植物识别重命名 App (PlantIdentifier)

基于豆包视觉大模型的 Android 植物图片批量识别与重命名工具。

## 功能特性

- 批量从相册选择植物图片
- 调用豆包视觉大模型 AI 识别植物（科、属、种）
- 自动匹配 fpga4 植物科号对照表
- 按格式自动重命名：`科号+科名+拉丁学名+中文名`
- 支持手动编辑修正识别结果
- 支持选择/取消选择单张图片
- 识别进度实时显示

## 命名格式示例

```
143蔷薇科Rosaceae月季花Rosa_chinensis.jpg
```

- `143` — 科号（来自 fpga4 APG4 对照表）
- `蔷薇科` — 科中文名
- `Rosaceae` — 科拉丁名（AI识别返回）
- `月季花` — 中文常用名
- `Rosa_chinensis` — 种拉丁学名（空格替换为下划线）

## 环境要求

- Android Studio Hedgehog (2023.1.1) 或更高版本
- JDK 17
- Android SDK 34
- 最低支持 Android 8.0 (API 26)
- Gradle 8.7

## 快速开始

### 1. 打开项目

用 Android Studio 打开 `F:\zhiwuAI\PlantIdentifier` 目录，等待 Gradle Sync 完成。

> 如果 Gradle Wrapper 缺失，在项目根目录执行：
> ```
> gradle wrapper --gradle-version 8.7
> ```

### 2. 配置 API Key

1. 注册并登录 [火山引擎方舟平台](https://www.volcengine.com/product/ark)
2. 创建 API Key（在「API Key 管理」中）
3. 开通视觉模型（默认 `doubao-seed-2-1-pro-260628`，Seed 2.1 Pro 视觉识别最强）
4. （可选）创建推理接入点，获取 `ep-` 开头的接入点 ID
5. 在 App 中点击右上角设置图标，填入 API Key 和接入点信息

### 3. 运行

连接 Android 设备或启动模拟器，点击 Run 按钮安装运行。

## 使用流程

1. **选择图片** — 点击「选择图片」按钮，从相册多选植物图片
2. **开始识别** — 点击底部「开始识别」，AI 批量识别所有选中图片
3. **检查/修正** — 识别完成后可点击每条结果右侧的编辑按钮手动修正
4. **批量重命名** — 确认无误后点击「批量重命名」，文件将按格式重命名

## 项目结构

```
PlantIdentifier/
├── app/
│   ├── build.gradle.kts              # App 模块构建配置
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml       # 清单文件
│       ├── assets/
│       │   └── fpga4.txt             # APG4植物科号对照表（700+科+同义词）
│       ├── java/com/zhiwu/plantid/
│       │   ├── MainActivity.kt       # 主 Activity
│       │   ├── data/
│       │   │   ├── PlantInfo.kt      # 植物信息数据类
│       │   │   ├── FamilyMapping.kt  # 科号映射表加载与匹配
│       │   │   └── DoubaoApiService.kt  # 豆包视觉API调用
│       │   ├── ui/
│       │   │   ├── theme/            # Compose 主题
│       │   │   ├── components/       # UI 组件
│       │   │   │   ├── PlantResultItem.kt   # 图片结果卡片
│       │   │   │   ├── EditResultDialog.kt  # 编辑对话框
│       │   │   │   └── SettingsDialog.kt    # 设置对话框
│       │   │   ├── viewmodel/
│       │   │   │   └── PlantViewModel.kt    # 业务逻辑 ViewModel
│       │   │   └── MainScreen.kt     # 主界面
│       │   └── util/
│       │       ├── FileRenamer.kt    # 文件重命名（兼容Android 10+）
│       │       └── ImageUtils.kt     # 图片工具类
│       └── res/                      # 资源文件
├── build.gradle.kts                  # 项目级构建配置
├── settings.gradle.kts
├── gradle.properties
└── gradlew.bat                       # Windows Gradle 脚本
```

## 技术栈

- **语言**: Kotlin
- **UI**: Jetpack Compose + Material 3
- **架构**: MVVM (ViewModel + StateFlow)
- **网络**: OkHttp
- **图片加载**: Coil
- **异步**: Kotlin Coroutines
- **AI 模型**: Doubao-Seed-2.1-pro (doubao-seed-2-1-pro-260628)，detail=xhigh 细粒度识别

## API 调用说明

豆包视觉模型通过火山引擎方舟平台的 OpenAI 兼容接口调用：

- **Endpoint**: `https://ark.cn-beijing.volces.com/api/v3/chat/completions`
- **默认模型**: `doubao-seed-2-1-pro-260628` (Seed 2.1 Pro)
- **认证**: `Authorization: Bearer <API_KEY>`
- **图片传输**: Base64 编码（自动压缩至 2048px 边长，JPEG 质量 90%）
- **细粒度识别**: `detail: "xhigh"` 模式，保留植物叶片、花蕊等细节
- **输出格式**: 结构化 JSON（科名、拉丁名、中文名、置信度、识别依据）
- **超时**: 读取超时 120 秒（适配 Seed 2.1 深度思考）

## fpga4 科号对照表 (APG4 分类系统)

对照表位于 `app/src/main/assets/fpga4.txt`，基于 APG4 分类系统，收录 700+ 植物科，编号分为四个系列：

| 系列 | 前缀 | 范围 | 类群 |
|------|------|------|------|
| B 系列 | B | B1-B224 | 苔藓植物 |
| F 系列 | F | F1-F53 | 蕨类植物 |
| G 系列 | G | G1-G13 | 裸子植物 |
| 数字系列 | 无 | 1-426 | 被子植物 |

### 文件格式

```
# 标准科号行: 科号 科中文名
143 蔷薇科
G7 柏科
B9 地钱科
F53 水龙骨科

# 同义词映射行: SYNONYM 旧科名 标准科名
SYNONYM 槭树科 无患子科
SYNONYM 木犀科 木樨科
SYNONYM 萝藦科 夹竹桃科
```

### 匹配逻辑

1. AI 返回科中文名 → 先查同义词映射（旧名→标准名）
2. 用标准名查对照表获取科号
3. 支持去/加"科"字后缀的模糊匹配
4. 未匹配到的科使用 `999` 作为科号
5. 可直接编辑该文件增删科目录和同义词

## 常见问题

### Q: 识别失败怎么办？
A: 检查网络连接和 API Key 是否正确。识别失败的图片可以手动编辑填写结果后再重命名。

### Q: 重命名后文件在哪里？
A: 文件在原位置被重命名（Android 10+ 通过 MediaStore 更新），不会移动文件位置。

### Q: 如何更换 AI 模型？
A: 在设置中修改模型名称，或填写新的推理接入点 ID。支持所有豆包系列视觉模型。

### Q: 批量识别速度慢？
A: 图片会逐张串行识别以避免 API 限流。可在火山引擎控制台提升 RPM 限制。

## 许可证

MIT License
