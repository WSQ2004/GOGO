package com.zhiwu.plantid

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.zhiwu.plantid.ui.MainScreen
import com.zhiwu.plantid.ui.theme.PlantIdentifierTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            PlantIdentifierTheme {
                MainScreen()
            }
        }
    }
}
