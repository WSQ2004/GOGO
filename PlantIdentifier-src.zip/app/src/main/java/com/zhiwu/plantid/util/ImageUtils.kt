package com.zhiwu.plantid.util

import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import android.webkit.MimeTypeMap

/**
 * 图片工具类
 */
object ImageUtils {

    /**
     * 从Uri获取文件名
     */
    fun getFileName(context: Context, uri: Uri): String {
        var fileName = "unknown_${System.currentTimeMillis()}"
        try {
            if ("file" == uri.scheme) {
                fileName = uri.lastPathSegment ?: fileName
            } else {
                val projection = arrayOf(MediaStore.Images.Media.DISPLAY_NAME)
                context.contentResolver.query(uri, projection, null, null, null)?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val columnIndex = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
                        fileName = cursor.getString(columnIndex)
                    }
                }
            }
        } catch (e: Exception) {
            // 使用默认名
        }
        return fileName
    }

    /**
     * 从Uri获取MIME类型
     */
    fun getMimeType(context: Context, uri: Uri): String {
        return try {
            context.contentResolver.getType(uri) ?: run {
                val extension = MimeTypeMap.getFileExtensionFromUrl(uri.toString())
                MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension.lowercase()) ?: "image/jpeg"
            }
        } catch (e: Exception) {
            "image/jpeg"
        }
    }

    /**
     * 检查Uri是否为图片类型
     */
    fun isImage(context: Context, uri: Uri): Boolean {
        val mimeType = getMimeType(context, uri)
        return mimeType.startsWith("image/")
    }

    /**
     * 获取文件扩展名（不含点）
     */
    fun getExtension(fileName: String): String {
        val dotIndex = fileName.lastIndexOf('.')
        return if (dotIndex >= 0 && dotIndex < fileName.length - 1) {
            fileName.substring(dotIndex + 1).lowercase()
        } else {
            "jpg"
        }
    }
}
