package com.zhiwu.plantid.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Pending
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.zhiwu.plantid.data.PlantInfo
import com.zhiwu.plantid.data.RecognitionStatus
import com.zhiwu.plantid.ui.theme.ErrorRed
import com.zhiwu.plantid.ui.theme.GrayMedium
import com.zhiwu.plantid.ui.theme.SuccessGreen
import com.zhiwu.plantid.ui.theme.WarningOrange

@Composable
fun PlantResultItem(
    plant: PlantInfo,
    onToggleSelect: () -> Unit,
    onEdit: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (plant.isSelected)
                MaterialTheme.colorScheme.surface
            else
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // 选择圆圈
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .clip(CircleShape)
                    .background(
                        if (plant.isSelected) MaterialTheme.colorScheme.primary
                        else Color.Transparent
                    )
                    .clickable { onToggleSelect() },
                contentAlignment = Alignment.Center
            ) {
                if (plant.isSelected) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .size(20.dp)
                            .clip(CircleShape)
                            .background(GrayMedium.copy(alpha = 0.3f))
                    )
                }
            }

            Spacer(modifier = Modifier.width(10.dp))

            // 缩略图
            Box(
                modifier = Modifier
                    .size(72.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
            ) {
                AsyncImage(
                    model = plant.uri,
                    contentDescription = null,
                    modifier = Modifier.size(72.dp),
                    contentScale = ContentScale.Crop
                )
                // 状态角标
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .size(20.dp)
                        .clip(CircleShape)
                        .background(getStatusColor(plant.status)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = getStatusIcon(plant.status),
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(12.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            // 信息区域
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Text(
                    text = plant.originalName,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                if (plant.status == RecognitionStatus.RECOGNIZING) {
                    Spacer(modifier = Modifier.height(4.dp))
                    LinearProgressIndicator(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(3.dp),
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "识别中...",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                } else if (plant.hasResult()) {
                    Text(
                        text = "${plant.familyCode} ${plant.familyName} · ${plant.chineseName}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = plant.speciesLatin.ifEmpty { plant.familyLatin },
                        style = MaterialTheme.typography.bodySmall,
                        color = GrayMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    // 预览新文件名
                    Text(
                        text = "→ ${plant.generateNewFileName()}",
                        style = MaterialTheme.typography.labelSmall,
                        color = SuccessGreen,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                } else if (plant.status == RecognitionStatus.FAILED) {
                    Text(
                        text = "失败: ${plant.errorMessage}",
                        style = MaterialTheme.typography.bodySmall,
                        color = ErrorRed,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                } else if (plant.status == RecognitionStatus.RENAMED) {
                    Text(
                        text = "已重命名: ${plant.generateNewFileName()}",
                        style = MaterialTheme.typography.bodySmall,
                        color = SuccessGreen,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                } else {
                    Text(
                        text = "待识别",
                        style = MaterialTheme.typography.bodySmall,
                        color = GrayMedium
                    )
                }
            }

            // 编辑按钮
            if (plant.hasResult() || plant.status == RecognitionStatus.FAILED) {
                IconButton(onClick = onEdit) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = "编辑",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

private fun getStatusColor(status: RecognitionStatus): Color {
    return when (status) {
        RecognitionStatus.PENDING -> GrayMedium
        RecognitionStatus.RECOGNIZING -> WarningOrange
        RecognitionStatus.SUCCESS -> SuccessGreen
        RecognitionStatus.FAILED -> ErrorRed
        RecognitionStatus.RENAMED -> SuccessGreen
    }
}

private fun getStatusIcon(status: RecognitionStatus): androidx.compose.ui.graphics.vector.ImageVector {
    return when (status) {
        RecognitionStatus.PENDING -> Icons.Default.Pending
        RecognitionStatus.RECOGNIZING -> Icons.Default.Pending
        RecognitionStatus.SUCCESS -> Icons.Default.CheckCircle
        RecognitionStatus.FAILED -> Icons.Default.Error
        RecognitionStatus.RENAMED -> Icons.Default.CheckCircle
    }
}
