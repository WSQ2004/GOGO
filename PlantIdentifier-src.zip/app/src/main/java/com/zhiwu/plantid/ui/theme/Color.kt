package com.zhiwu.plantid.ui.theme

import androidx.compose.ui.graphics.Color

val GreenPrimary = Color(0xFF2E7D32)
val GreenDark = Color(0xFF1B5E20)
val GreenLight = Color(0xFFA5D6A7)
val LeafAccent = Color(0xFF66BB6A)
val White = Color(0xFFFFFFFF)
val Black = Color(0xFF000000)
val GrayLight = Color(0xFFF5F5F5)
val GrayMedium = Color(0xFF9E9E9E)
val GrayDark = Color(0xFF424242)
val ErrorRed = Color(0xFFE53935)
val SuccessGreen = Color(0xFF43A047)
val WarningOrange = Color(0xFFFB8C00)
val Background = Color(0xFFFAFAFA)
val CardBackground = Color(0xFFFFFFFF)
