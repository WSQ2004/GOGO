package com.zhiwu.plantid.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Protocol
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

/**
 * 豆包视觉模型 API 服务
 * 调用火山引擎方舟平台的 Doubao-Seed-2.1-pro 进行植物识别
 * 使用 Responses API (/api/v3/responses) 格式
 */
class DoubaoApiService(
    private val context: Context,
    private val apiKey: String,
    private val endpointId: String,
    private val model: String = "doubao-seed-2-1-pro-260628"
) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(300, TimeUnit.SECONDS)
        .writeTimeout(120, TimeUnit.SECONDS)
        .protocols(listOf(Protocol.HTTP_1_1)) // 强制HTTP/1.1，避免HTTP/2兼容问题导致挂起
        .retryOnConnectionFailure(true)
        .build()

    companion object {
        private const val API_URL = "https://ark.cn-beijing.volces.com/api/v3/responses"
        private const val MAX_IMAGE_SIZE = 1024 // 降低分辨率减少请求体大小
        private const val MAX_IMAGE_QUALITY = 60 // 降低质量加快传输
    }

    /**
     * 识别植物图片
     */
    suspend fun recognizePlant(imageUri: Uri): Result<RecognitionData> = withContext(Dispatchers.IO) {
        try {
            android.util.Log.d("DoubaoApi", "开始处理图片: $imageUri")
            // 1. 读取并压缩图片
            val base64Image = uriToBase64(imageUri)
            if (base64Image.isEmpty()) {
                return@withContext Result.failure(Exception("图片读取失败"))
            }
            android.util.Log.d("DoubaoApi", "图片处理完成, base64长度: ${base64Image.length}")

            // 2. 构建请求（Responses API 格式）
            val requestBody = buildRequestBody(base64Image)
            val modelUsed = if (endpointId.startsWith("ep-")) endpointId else model
            android.util.Log.d("DoubaoApi", "发送API请求, 模型: $modelUsed, URL: $API_URL")
            android.util.Log.d("DoubaoApi", "请求体长度: ${requestBody.contentLength()}")

            val request = Request.Builder()
                .url(API_URL)
                .addHeader("Authorization", "Bearer $apiKey")
                .addHeader("Content-Type", "application/json")
                .addHeader("User-Agent", "volcengine-ark-runtime/android-1.0")
                .post(requestBody)
                .build()

            // 3. 执行请求
            client.newCall(request).execute().use { response ->
                val responseBody = response.body?.string() ?: ""
                android.util.Log.d("DoubaoApi", "API响应码: ${response.code}, 长度: ${responseBody.length}")
                if (responseBody.isNotEmpty()) {
                    android.util.Log.d("DoubaoApi", "响应内容前500字: ${responseBody.take(500)}")
                }
                if (!response.isSuccessful) {
                    return@withContext Result.failure(
                        Exception("API错误 ${response.code}: ${responseBody.take(300)}")
                    )
                }

                // 4. 解析 Responses API 响应
                val content = parseResponsesOutput(responseBody)
                if (content.isEmpty()) {
                    return@withContext Result.failure(Exception("API返回为空: ${responseBody.take(300)}"))
                }

                // 5. 解析识别结果
                val data = parseRecognitionResult(content)
                Result.success(data)
            }
        } catch (e: Exception) {
            android.util.Log.e("DoubaoApi", "识别失败: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * 构建请求体（Responses API 格式）
     * 使用 input 数组，图片类型 input_image，文本类型 input_text
     */
    private fun buildRequestBody(base64Image: String): okhttp3.RequestBody {
        // 系统提示词合并到用户文本中（Responses API 标准做法）
        val systemPrompt = """
你是一位资深植物分类学家，精通APG4分类系统。
请仔细观察图片中植物的形态特征，给出最准确的分类鉴定。

严格按照以下JSON格式返回结果（不要返回JSON以外的任何内容，不要使用markdown代码块）：
{
  "family_chinese": "科中文名",
  "family_latin": "科拉丁名",
  "species_latin": "种拉丁学名（双名法）",
  "chinese_name": "中文常用名",
  "confidence": 0.0到1.0的数字,
  "note": "简要识别依据"
}

要求：优先识别到种；无法确定则到属；再不行到科。只返回纯JSON。
        """.trimIndent()

        val userText = "$systemPrompt\n\n请识别这张图片中的植物，给出科、种的分类信息。"

        // 图片消息（input_image 类型）
        val imageMessage = JSONObject().apply {
            put("type", "input_image")
            put("image_url", "data:image/jpeg;base64,$base64Image")
        }

        // 文本消息（input_text 类型）
        val textMessage = JSONObject().apply {
            put("type", "input_text")
            put("text", userText)
        }

        // 用户消息内容数组
        val userContent = JSONArray().apply {
            put(imageMessage)
            put(textMessage)
        }

        // 用户消息
        val userMessage = JSONObject().apply {
            put("role", "user")
            put("content", userContent)
        }

        // input 数组
        val inputArray = JSONArray().apply {
            put(userMessage)
        }

        // 最终请求体
        val json = JSONObject().apply {
            // 使用 endpointId 或 model 名称
            if (endpointId.startsWith("ep-")) {
                put("model", endpointId)
            } else {
                put("model", model)
            }
            put("input", inputArray)
            // 关闭深度思考，避免响应超时（Seed模型默认思考可能耗时几分钟）
            put("thinking", JSONObject().apply {
                put("type", "disabled")
            })
            // 极低温度，保证结果稳定
            put("temperature", 0.1)
        }

        val jsonStr = json.toString()
        android.util.Log.d("DoubaoApi", "请求JSON长度: ${jsonStr.length}")
        return jsonStr.toRequestBody("application/json".toMediaType())
    }

    /**
     * 解析 Responses API 的输出
     * 响应格式: output[].content[].text
     */
    private fun parseResponsesOutput(responseBody: String): String {
        return try {
            val json = JSONObject(responseBody)
            val outputArray = json.optJSONArray("output") ?: return ""
            for (i in 0 until outputArray.length()) {
                val outputItem = outputArray.getJSONObject(i)
                val contentArray = outputItem.optJSONArray("content") ?: continue
                for (j in 0 until contentArray.length()) {
                    val contentItem = contentArray.getJSONObject(j)
                    val type = contentItem.optString("type", "")
                    if (type == "output_text" || type == "text") {
                        val text = contentItem.optString("text", "")
                        if (text.isNotEmpty()) return text
                    }
                }
            }
            // 备用：尝试直接找 text 字段
            json.optString("output_text", "")
        } catch (e: Exception) {
            android.util.Log.e("DoubaoApi", "解析响应失败: ${e.message}")
            ""
        }
    }

    /**
     * 将Uri转换为Base64字符串（高效压缩，使用inSampleSize避免OOM）
     */
    private fun uriToBase64(uri: Uri): String {
        return try {
            // 第一次解码：只读取图片尺寸
            val boundsOptions = BitmapFactory.Options().apply {
                inJustDecodeBounds = true
            }
            context.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, boundsOptions)
            }

            // 计算 inSampleSize
            val sampleSize = calculateInSampleSize(
                boundsOptions.outWidth,
                boundsOptions.outHeight,
                MAX_IMAGE_SIZE,
                MAX_IMAGE_SIZE
            )

            // 第二次解码：使用 inSampleSize 高效加载
            val decodeOptions = BitmapFactory.Options().apply {
                inSampleSize = sampleSize
                inPreferredConfig = Bitmap.Config.RGB_565
            }

            val bitmap = context.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, decodeOptions)
            } ?: return ""

            // 如果仍大于目标尺寸，再精确缩放
            val finalBitmap = if (bitmap.width > MAX_IMAGE_SIZE || bitmap.height > MAX_IMAGE_SIZE) {
                scaleBitmap(bitmap)
            } else {
                bitmap
            }

            // 压缩为 JPEG
            val outputStream = ByteArrayOutputStream()
            finalBitmap.compress(Bitmap.CompressFormat.JPEG, MAX_IMAGE_QUALITY, outputStream)
            val bytes = outputStream.toByteArray()

            // 回收内存
            if (finalBitmap !== bitmap) {
                finalBitmap.recycle()
            }
            bitmap.recycle()

            Base64.encodeToString(bytes, Base64.NO_WRAP)
        } catch (e: Exception) {
            android.util.Log.e("DoubaoApi", "图片处理失败: ${e.message}", e)
            ""
        }
    }

    /**
     * 计算 inSampleSize（2的幂次方）
     */
    private fun calculateInSampleSize(width: Int, height: Int, reqWidth: Int, reqHeight: Int): Int {
        var inSampleSize = 1
        if (width > reqWidth || height > reqHeight) {
            val halfWidth = width / 2
            val halfHeight = height / 2
            while ((halfWidth / inSampleSize) >= reqWidth && (halfHeight / inSampleSize) >= reqHeight) {
                inSampleSize *= 2
            }
        }
        return inSampleSize
    }

    /**
     * 精确缩放图片
     */
    private fun scaleBitmap(bitmap: Bitmap): Bitmap {
        val width = bitmap.width
        val height = bitmap.height
        val maxDim = maxOf(width, height)
        if (maxDim <= MAX_IMAGE_SIZE) return bitmap

        val scale = MAX_IMAGE_SIZE.toFloat() / maxDim
        val newWidth = (width * scale).toInt()
        val newHeight = (height * scale).toInt()
        return Bitmap.createScaledBitmap(bitmap, newWidth, newHeight, true)
    }

    /**
     * 解析识别结果JSON
     */
    private fun parseRecognitionResult(content: String): RecognitionData {
        return try {
            val jsonStr = extractJson(content)
            val json = JSONObject(jsonStr)

            RecognitionData(
                familyChinese = json.optString("family_chinese", "").trim(),
                familyLatin = json.optString("family_latin", "").trim(),
                speciesLatin = json.optString("species_latin", "").trim(),
                chineseName = json.optString("chinese_name", "").trim(),
                confidence = json.optDouble("confidence", 0.0).toFloat(),
                note = json.optString("note", "").trim(),
                rawContent = content
            )
        } catch (e: Exception) {
            RecognitionData(
                familyChinese = "",
                familyLatin = "",
                speciesLatin = "",
                chineseName = "",
                confidence = 0f,
                note = "解析失败: ${e.message}",
                rawContent = content
            )
        }
    }

    /**
     * 从文本中提取JSON字符串
     */
    private fun extractJson(text: String): String {
        var cleaned = text.trim()
        if (cleaned.startsWith("```")) {
            cleaned = cleaned.replaceFirst("```json", "").replaceFirst("```", "")
            cleaned = cleaned.removeSuffix("```").trim()
        }
        val start = cleaned.indexOf("{")
        val end = cleaned.lastIndexOf("}")
        if (start >= 0 && end > start) {
            return cleaned.substring(start, end + 1)
        }
        return cleaned
    }
}

/**
 * 识别结果数据
 */
data class RecognitionData(
    val familyChinese: String,
    val familyLatin: String,
    val speciesLatin: String,
    val chineseName: String,
    val confidence: Float,
    val note: String,
    val rawContent: String
)
