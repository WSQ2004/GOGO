package com.zhiwu.plantid.data

import android.content.Context

/**
 * 植物科号映射表 (APG4 分类系统)
 * 从 assets/fpga4.txt 加载，支持两种行格式:
 *   科号 科中文名          (如: 143 蔷薇科, B1 裸蒴苔科, G7 柏科)
 *   SYNONYM 旧科名 标准科名 (同义词映射，如: SYNONYM 槭树科 无患子科)
 *
 * 编号系列:
 *   B 系列 - 苔藓植物 (B1-B224)
 *   F 系列 - 蕨类植物 (F1-F53)
 *   G 系列 - 裸子植物 (G1-G13)
 *   数字系列 - 被子植物 (1-426)
 */
object FamilyMapping {

    private val codeToFamily = mutableMapOf<String, FamilyEntry>()
    private val nameToCode = mutableMapOf<String, String>()
    private val synonymMap = mutableMapOf<String, String>() // 旧科名 -> 标准科名

    data class FamilyEntry(
        val code: String,
        val chineseName: String,
        val latinName: String = ""
    )

    /**
     * 从 assets 加载映射表
     */
    fun load(context: Context) {
        try {
            val inputStream = context.assets.open("fpga4.txt")
            val content = inputStream.bufferedReader().use { it.readText() }
            parse(content)
        } catch (e: Exception) {
            loadDefault()
        }
    }

    /**
     * 解析映射表内容
     */
    fun parse(content: String) {
        codeToFamily.clear()
        nameToCode.clear()
        synonymMap.clear()

        content.lines().forEach { line ->
            val trimmed = line.trim()
            // 跳过注释和空行
            if (trimmed.isEmpty() || trimmed.startsWith("#") || trimmed.startsWith("-")) {
                return@forEach
            }

            // 同义词映射行: SYNONYM 旧科名 标准科名
            if (trimmed.startsWith("SYNONYM")) {
                val parts = trimmed.split(Regex("\\s+"), limit = 3)
                if (parts.size >= 3) {
                    val oldName = parts[1].trim()
                    val standardName = parts[2].trim()
                    synonymMap[oldName] = standardName
                }
                return@forEach
            }

            // 标准科号行: 科号 科中文名
            val parts = trimmed.split(Regex("\\s+"), limit = 2)
            if (parts.size >= 2) {
                val code = parts[0].trim()
                val chineseName = parts[1].trim()
                val entry = FamilyEntry(code, chineseName)
                codeToFamily[code] = entry
                nameToCode[chineseName] = code
            }
        }
    }

    /**
     * 解析同义词（旧科名 -> 标准科名）
     */
    fun resolveSynonym(name: String): String {
        return synonymMap[name.trim()] ?: name.trim()
    }

    /**
     * 根据科中文名查找科号（先解析同义词）
     */
    fun findCodeByName(chineseName: String): String? {
        val standardName = resolveSynonym(chineseName)
        return nameToCode[standardName]
    }

    /**
     * 根据科号查找科信息
     */
    fun findByCode(code: String): FamilyEntry? {
        return codeToFamily[code]
    }

    /**
     * 根据科名自动匹配，返回科号和标准科名
     * 流程: 同义词解析 -> 精确匹配 -> 去"科"字后缀匹配 -> 返回999
     */
    fun matchFamily(chineseName: String?, latinName: String? = null): FamilyEntry {
        if (!chineseName.isNullOrBlank()) {
            // 1. 同义词解析后精确匹配
            val standardName = resolveSynonym(chineseName.trim())
            nameToCode[standardName]?.let { code ->
                codeToFamily[code]?.let { return it }
            }

            // 2. 去掉"科"字后缀后再匹配
            val nameWithoutSuffix = standardName.removeSuffix("科").trim()
            if (nameWithoutSuffix != standardName && nameWithoutSuffix.isNotEmpty()) {
                nameToCode["${nameWithoutSuffix}科"]?.let { code ->
                    codeToFamily[code]?.let { return it }
                }
            }

            // 3. 加上"科"字后缀后再匹配（AI可能返回不带"科"的名称）
            if (!standardName.endsWith("科")) {
                nameToCode["${standardName}科"]?.let { code ->
                    codeToFamily[code]?.let { return it }
                }
            }
        }

        // 未找到，使用999
        val displayName = if (!chineseName.isNullOrBlank()) {
            resolveSynonym(chineseName.trim())
        } else {
            "未知科"
        }
        return FamilyEntry(
            code = "999",
            chineseName = displayName,
            latinName = latinName ?: ""
        )
    }

    fun getAllFamilies(): List<FamilyEntry> = codeToFamily.values.sortedBy { it.code }

    fun getSynonymCount(): Int = synonymMap.size

    fun size(): Int = codeToFamily.size

    /**
     * 内置默认映射表（assets加载失败时的兜底）
     * 使用 APG4 编号体系
     */
    private fun loadDefault() {
        val defaults = listOf(
            "G1" to "苏铁科",
            "G3" to "银杏科",
            "G7" to "柏科",
            "G10" to "松科",
            "14" to "木兰科",
            "19" to "蜡梅科",
            "25" to "樟科",
            "28" to "天南星科",
            "60" to "百合科",
            "61" to "兰科",
            "70" to "鸢尾科",
            "73" to "石蒜科",
            "74" to "天门冬科",
            "76" to "棕榈科",
            "78" to "鸭跖草科",
            "85" to "芭蕉科",
            "89" to "姜科",
            "98" to "莎草科",
            "103" to "禾本科",
            "106" to "罂粟科",
            "110" to "小檗科",
            "111" to "毛茛科",
            "113" to "莲科",
            "124" to "金缕梅科",
            "129" to "虎耳草科",
            "130" to "景天科",
            "136" to "葡萄科",
            "140" to "豆科",
            "143" to "蔷薇科",
            "146" to "胡颓子科",
            "147" to "鼠李科",
            "148" to "榆科",
            "150" to "桑科",
            "151" to "荨麻科",
            "153" to "壳斗科",
            "155" to "胡桃科",
            "158" to "桦木科",
            "163" to "葫芦科",
            "166" to "秋海棠科",
            "168" to "卫矛科",
            "171" to "酢浆草科",
            "183" to "藤黄科",
            "186" to "金丝桃科",
            "200" to "堇菜科",
            "202" to "西番莲科",
            "204" to "杨柳科",
            "207" to "大戟科",
            "208" to "亚麻科",
            "211" to "叶下珠科",
            "212" to "牻牛儿苗科",
            "215" to "千屈菜科",
            "216" to "柳叶菜科",
            "218" to "桃金娘科",
            "219" to "野牡丹科",
            "235" to "漆树科",
            "236" to "无患子科",
            "237" to "芸香科",
            "238" to "苦木科",
            "239" to "楝科",
            "247" to "锦葵科",
            "249" to "瑞香科",
            "255" to "旱金莲科",
            "268" to "木樨草科",
            "271" to "十字花科",
            "283" to "檀香科",
            "287" to "桑寄生科",
            "289" to "柽柳科",
            "290" to "白花丹科",
            "291" to "蓼科",
            "292" to "茅膏菜科",
            "303" to "石竹科",
            "305" to "苋科",
            "312" to "番杏科",
            "313" to "商陆科",
            "316" to "紫茉莉科",
            "323" to "马齿苋科",
            "325" to "仙人掌科",
            "326" to "蓝果树科",
            "328" to "绣球科",
            "332" to "山茱萸科",
            "333" to "凤仙花科",
            "337" to "花荵科",
            "341" to "山榄科",
            "342" to "柿科",
            "343" to "报春花科",
            "344" to "山茶科",
            "345" to "山矾科",
            "347" to "安息香科",
            "350" to "猕猴桃科",
            "353" to "杜鹃花科",
            "358" to "杜仲科",
            "360" to "茜草科",
            "361" to "龙胆科",
            "362" to "马钱科",
            "364" to "夹竹桃科",
            "365" to "紫草科",
            "367" to "旋花科",
            "368" to "茄科",
            "374" to "木樨科",
            "378" to "苦苣苔科",
            "379" to "车前科",
            "380" to "玄参科",
            "386" to "爵床科",
            "387" to "紫葳科",
            "388" to "狸藻科",
            "391" to "马鞭草科",
            "392" to "唇形科",
            "397" to "列当科",
            "402" to "冬青科",
            "404" to "桔梗科",
            "413" to "菊科",
            "418" to "五福花科",
            "419" to "忍冬科",
            "423" to "海桐科",
            "424" to "五加科",
            "426" to "伞形科",
            "F3" to "卷柏科",
            "F4" to "木贼科",
            "F9" to "膜蕨科",
            "F25" to "桫椤科",
            "F29" to "鳞始蕨科",
            "F30" to "凤尾蕨科",
            "F37" to "铁角蕨科",
            "F41" to "蹄盖蕨科",
            "F42" to "金星蕨科",
            "F45" to "鳞毛蕨科",
            "F53" to "水龙骨科",
            "B9" to "地钱科",
            "B14" to "蛇苔科",
            "B90" to "泥炭藓科",
            "B91" to "黑藓科",
            "B95" to "金发藓科",
            "B101" to "葫芦藓科",
            "B128" to "曲尾藓科",
            "B138" to "丛藓科",
            "B149" to "提灯藓科",
            "B152" to "真藓科",
            "B193" to "塔藓科",
            "B194" to "青藓科",
            "B198" to "灰藓科",
            "B210" to "绢藓科",
            "B216" to "羽藓科",
            "B221" to "角苔科"
        )

        defaults.forEach { (code, cn) ->
            val entry = FamilyEntry(code, cn)
            codeToFamily[code] = entry
            nameToCode[cn] = code
        }

        // 内置同义词
        val defaultSynonyms = listOf(
            "木犀科" to "木樨科",
            "槭树科" to "无患子科",
            "七叶树科" to "无患子科",
            "杉科" to "柏科",
            "萝藦科" to "夹竹桃科",
            "椴树科" to "锦葵科",
            "木棉科" to "锦葵科",
            "梧桐科" to "锦葵科",
            "紫金牛科" to "报春花科",
            "败酱科" to "忍冬科",
            "川续断科" to "忍冬科",
            "接骨木科" to "忍冬科",
            "荚蒾科" to "忍冬科",
            "八仙花科" to "绣球科",
            "绣球花科" to "绣球科",
            "菟丝子科" to "旋花科",
            "半边莲科" to "桔梗科",
            "厚壳树科" to "紫草科",
            "菠萝蜜科" to "桑科",
            "葱科" to "阿福花科",
            "芦荟科" to "阿福花科",
            "萱草科" to "阿福花科",
            "铃兰科" to "天门冬科",
            "玉簪科" to "天门冬科",
            "龙舌兰科" to "天门冬科",
            "假叶树科" to "天门冬科",
            "风信子科" to "天门冬科"
        )
        defaultSynonyms.forEach { (old, standard) ->
            synonymMap[old] = standard
        }
    }
}
