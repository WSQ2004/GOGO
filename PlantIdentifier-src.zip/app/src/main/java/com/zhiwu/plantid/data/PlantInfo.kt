package com.zhiwu.plantid.data

import android.net.Uri

/**
 * 植物识别结果数据类
 */
data class PlantInfo(
    val id: String = System.nanoTime().toString(),
    val uri: Uri,
    val originalName: String,
    val mimeType: String = "image/jpeg",

    // 识别结果
    var familyCode: String = "",      // 科号，如 "029"
    var familyName: String = "",      // 科中文名，如 "蔷薇科"
    var familyLatin: String = "",     // 科拉丁名，如 "Rosaceae"
    var speciesLatin: String = "",    // 种拉丁学名，如 "Rosa chinensis"
    var chineseName: String = "",     // 中文名，如 "月季花"
    var confidence: Float = 0f,       // 置信度 0-1
    var rawResponse: String = "",     // 原始API返回

    // 状态
    var status: RecognitionStatus = RecognitionStatus.PENDING,
    var errorMessage: String = "",
    var isSelected: Boolean = true
) {
    /**
     * 生成新文件名: 科号+科名+拉丁学名+中文名
     * 示例: 029蔷薇科Rosaceae月季花Rosa_chinensis.jpg
     */
    fun generateNewFileName(): String {
        val extension = when (mimeType) {
            "image/png" -> ".png"
            "image/webp" -> ".webp"
            "image/gif" -> ".gif"
            "image/bmp" -> ".bmp"
            else -> ".jpg"
        }
        // 拉丁学名中的空格替换为下划线
        val latinSafe = speciesLatin.replace(" ", "_")
        val name = "$familyCode$familyName$familyLatin$chineseName$latinSafe"
        // 移除文件名中不允许的字符
        return name.replace(Regex("[\\\\/:*?\"<>|]"), "_") + extension
    }

    fun hasResult(): Boolean = familyCode.isNotEmpty() && chineseName.isNotEmpty()
}

enum class RecognitionStatus {
    PENDING,      // 待识别
    RECOGNIZING,  // 识别中
    SUCCESS,      // 识别成功
    FAILED,       // 识别失败
    RENAMED       // 已重命名
}
