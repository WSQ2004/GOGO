package com.zhiwu.plantid.util

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import com.zhiwu.plantid.data.PlantInfo
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

/**
 * 文件重命名工具
 * 支持 MediaStore (Android 10+) 和 File API (旧版本)
 */
object FileRenamer {

    private const val TAG = "FileRenamer"

    /**
     * 批量重命名文件
     * @return 成功重命名的数量
     */
    suspend fun batchRename(
        context: Context,
        plants: List<PlantInfo>
    ): RenameResult {
        var successCount = 0
        var failCount = 0
        val errors = mutableListOf<Pair<String, String>>()

        plants.filter { it.isSelected && it.hasResult() }.forEach { plant ->
            try {
                val newName = plant.generateNewFileName()
                val result = renameFile(context, plant.uri, newName, plant.originalName)
                if (result) {
                    plant.status = com.zhiwu.plantid.data.RecognitionStatus.RENAMED
                    successCount++
                    Log.d(TAG, "重命名成功: ${plant.originalName} -> $newName")
                } else {
                    failCount++
                    errors.add(plant.originalName to "重命名失败")
                }
            } catch (e: Exception) {
                failCount++
                errors.add(plant.originalName to (e.message ?: "未知错误"))
                Log.e(TAG, "重命名异常: ${plant.originalName}", e)
            }
        }

        return RenameResult(successCount, failCount, errors)
    }

    /**
     * 重命名单个文件
     */
    private fun renameFile(
        context: Context,
        uri: Uri,
        newFileName: String,
        originalName: String
    ): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                renameViaMediaStore(context, uri, newFileName)
            } else {
                renameViaFileApi(context, uri, newFileName, originalName)
            }
        } catch (e: Exception) {
            Log.e(TAG, "renameFile error", e)
            false
        }
    }

    /**
     * Android 10+ 使用 MediaStore 重命名
     */
    private fun renameViaMediaStore(context: Context, uri: Uri, newFileName: String): Boolean {
        return try {
            val contentValues = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, newFileName)
            }
            val rows = context.contentResolver.update(uri, contentValues, null, null)
            rows > 0
        } catch (e: Exception) {
            Log.e(TAG, "renameViaMediaStore error", e)
            // 回退到复制删除方式
            renameViaCopyDelete(context, uri, newFileName)
        }
    }

    /**
     * 通过复制+删除方式重命名（兜底方案）
     */
    private fun renameViaCopyDelete(context: Context, uri: Uri, newFileName: String): Boolean {
        return try {
            // 读取原文件
            val inputStream = context.contentResolver.openInputStream(uri) ?: return false
            val tempFile = File(context.cacheDir, "temp_${System.currentTimeMillis()}")
            FileOutputStream(tempFile).use { output ->
                inputStream.copyTo(output)
            }
            inputStream.close()

            // 插入新文件到 MediaStore
            val contentValues = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, newFileName)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/PlantIdentifier")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
            }

            val newUri = context.contentResolver.insert(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                contentValues
            ) ?: return false

            // 写入数据
            context.contentResolver.openOutputStream(newUri)?.use { output ->
                FileInputStream(tempFile).copyTo(output)
            }

            // 完成写入
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                contentValues.clear()
                contentValues.put(MediaStore.Images.Media.IS_PENDING, 0)
                context.contentResolver.update(newUri, contentValues, null, null)
            }

            // 删除原文件
            try {
                context.contentResolver.delete(uri, null, null)
            } catch (e: Exception) {
                Log.w(TAG, "删除原文件失败", e)
            }

            tempFile.delete()
            true
        } catch (e: Exception) {
            Log.e(TAG, "renameViaCopyDelete error", e)
            false
        }
    }

    /**
     * 旧版本使用 File API 重命名
     */
    private fun renameViaFileApi(
        context: Context,
        uri: Uri,
        newFileName: String,
        originalName: String
    ): Boolean {
        return try {
            // 尝试从Uri获取文件路径
            val filePath = getFilePathFromUri(context, uri)
            if (filePath != null) {
                val oldFile = File(filePath)
                val newFile = File(oldFile.parent, newFileName)
                return oldFile.renameTo(newFile)
            }
            // 无法获取路径，使用复制删除方式
            renameViaCopyDelete(context, uri, newFileName)
        } catch (e: Exception) {
            Log.e(TAG, "renameViaFileApi error", e)
            false
        }
    }

    /**
     * 从Uri获取文件路径（仅用于旧版本）
     */
    private fun getFilePathFromUri(context: Context, uri: Uri): String? {
        if ("file" == uri.scheme) {
            return uri.path
        }
        if ("content" == uri.scheme) {
            val projection = arrayOf(MediaStore.Images.Media.DATA)
            try {
                context.contentResolver.query(uri, projection, null, null, null)?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val columnIndex = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA)
                        return cursor.getString(columnIndex)
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "getFilePathFromUri error", e)
            }
        }
        return null
    }
}

/**
 * 重命名结果
 */
data class RenameResult(
    val successCount: Int,
    val failCount: Int,
    val errors: List<Pair<String, String>>
)
