package com.zhiwu.plantid.ui.viewmodel

import android.app.Application
import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.zhiwu.plantid.data.DoubaoApiService
import com.zhiwu.plantid.data.FamilyMapping
import com.zhiwu.plantid.data.PlantInfo
import com.zhiwu.plantid.data.RecognitionStatus
import com.zhiwu.plantid.util.FileRenamer
import com.zhiwu.plantid.util.ImageUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class PlantViewModel(application: Application) : AndroidViewModel(application) {

    private val context: Context = application.applicationContext
    private val prefs: SharedPreferences =
        context.getSharedPreferences("plant_id_prefs", Context.MODE_PRIVATE)

    // UI状态
    private val _plants = MutableStateFlow<List<PlantInfo>>(emptyList())
    val plants: StateFlow<List<PlantInfo>> = _plants.asStateFlow()

    private val _isRecognizing = MutableStateFlow(false)
    val isRecognizing: StateFlow<Boolean> = _isRecognizing.asStateFlow()

    private val _isRenaming = MutableStateFlow(false)
    val isRenaming: StateFlow<Boolean> = _isRenaming.asStateFlow()

    private val _progress = MutableStateFlow(0f)
    val progress: StateFlow<Float> = _progress.asStateFlow()

    private val _currentProcessing = MutableStateFlow("")
    val currentProcessing: StateFlow<String> = _currentProcessing.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    private val _showSettings = MutableStateFlow(false)
    val showSettings: StateFlow<Boolean> = _showSettings.asStateFlow()

    private val _editingPlant = MutableStateFlow<PlantInfo?>(null)
    val editingPlant: StateFlow<PlantInfo?> = _editingPlant.asStateFlow()

    // 设置
    var apiKey: String
        get() = prefs.getString("api_key", "") ?: ""
        set(value) = prefs.edit().putString("api_key", value).apply()

    var endpointId: String
        get() = prefs.getString("endpoint_id", "") ?: ""
        set(value) = prefs.edit().putString("endpoint_id", value).apply()

    var modelName: String
        get() = prefs.getString("model_name", "doubao-seed-2-1-pro-260628") ?: "doubao-seed-2-1-pro-260628"
        set(value) = prefs.edit().putString("model_name", value).apply()

    init {
        // 加载科号映射表
        FamilyMapping.load(context)
    }

    /**
     * 添加选中的图片
     */
    fun addImages(uris: List<Uri>) {
        val newPlants = uris.map { uri ->
            PlantInfo(
                uri = uri,
                originalName = ImageUtils.getFileName(context, uri),
                mimeType = ImageUtils.getMimeType(context, uri)
            )
        }
        _plants.value = _plants.value + newPlants
        showMessage("已添加 ${newPlants.size} 张图片")
    }

    /**
     * 移除单张图片
     */
    fun removePlant(id: String) {
        _plants.value = _plants.value.filter { it.id != id }
    }

    /**
     * 清空所有图片
     */
    fun clearAll() {
        _plants.value = emptyList()
        _progress.value = 0f
    }

    /**
     * 切换选中状态
     */
    fun toggleSelect(id: String) {
        _plants.value = _plants.value.map {
            if (it.id == id) it.copy(isSelected = !it.isSelected) else it
        }
    }

    /**
     * 全选/取消全选
     */
    fun toggleSelectAll() {
        val allSelected = _plants.value.all { it.isSelected }
        _plants.value = _plants.value.map { it.copy(isSelected = !allSelected) }
    }

    /**
     * 开始批量识别
     */
    fun startRecognition() {
        if (apiKey.isEmpty()) {
            showMessage("请先在设置中配置 API Key")
            _showSettings.value = true
            return
        }

        val pendingPlants = _plants.value.filter { it.isSelected && it.status == RecognitionStatus.PENDING }
        if (pendingPlants.isEmpty()) {
            showMessage("没有待识别的图片")
            return
        }

        viewModelScope.launch {
            _isRecognizing.value = true
            _progress.value = 0f

            val apiService = DoubaoApiService(
                context = context,
                apiKey = apiKey,
                endpointId = endpointId,
                model = modelName
            )

            var successCount = 0
            var failCount = 0
            val total = pendingPlants.size

            pendingPlants.forEachIndexed { index, plant ->
                _currentProcessing.value = plant.originalName
                updatePlantStatus(plant.id, RecognitionStatus.RECOGNIZING)

                val result = apiService.recognizePlant(plant.uri)
                result.onSuccess { data ->
                    // 匹配科号（先同义词解析，再查APG4对照表）
                    val family = FamilyMapping.matchFamily(data.familyChinese)
                    updatePlantResult(
                        id = plant.id,
                        familyCode = family.code,
                        familyName = family.chineseName,
                        familyLatin = data.familyLatin,
                        speciesLatin = data.speciesLatin,
                        chineseName = data.chineseName,
                        confidence = data.confidence,
                        rawResponse = data.rawContent
                    )
                    successCount++
                }.onFailure { e ->
                    updatePlantError(plant.id, e.message ?: "识别失败")
                    failCount++
                }

                _progress.value = (index + 1).toFloat() / total
            }

            _isRecognizing.value = false
            _currentProcessing.value = ""
            showMessage("识别完成: 成功 $successCount, 失败 $failCount")
        }
    }

    /**
     * 开始批量重命名
     */
    fun startRename() {
        val readyPlants = _plants.value.filter { it.isSelected && it.hasResult() && it.status != RecognitionStatus.RENAMED }
        if (readyPlants.isEmpty()) {
            showMessage("没有可重命名的图片（请先识别并确认结果）")
            return
        }

        viewModelScope.launch {
            _isRenaming.value = true
            val result = withContext(Dispatchers.IO) {
                FileRenamer.batchRename(context, readyPlants)
            }
            _isRenaming.value = false
            showMessage("重命名完成: 成功 ${result.successCount}, 失败 ${result.failCount}")
            if (result.errors.isNotEmpty()) {
                result.errors.forEach { (name, error) ->
                    android.util.Log.w("PlantViewModel", "重命名失败: $name - $error")
                }
            }
        }
    }

    /**
     * 打开编辑对话框
     */
    fun startEdit(plant: PlantInfo) {
        _editingPlant.value = plant
    }

    /**
     * 保存编辑结果
     */
    fun saveEdit(updated: PlantInfo) {
        _plants.value = _plants.value.map {
            if (it.id == updated.id) updated.copy(status = RecognitionStatus.SUCCESS) else it
        }
        _editingPlant.value = null
        showMessage("已更新识别结果")
    }

    /**
     * 取消编辑
     */
    fun cancelEdit() {
        _editingPlant.value = null
    }

    fun openSettings() { _showSettings.value = true }
    fun closeSettings() { _showSettings.value = false }

    fun showMessage(msg: String) {
        _message.value = msg
    }

    fun clearMessage() {
        _message.value = null
    }

    // --- 内部更新方法 ---

    private fun updatePlantStatus(id: String, status: RecognitionStatus) {
        _plants.value = _plants.value.map {
            if (it.id == id) it.copy(status = status) else it
        }
    }

    private fun updatePlantResult(
        id: String,
        familyCode: String,
        familyName: String,
        familyLatin: String,
        speciesLatin: String,
        chineseName: String,
        confidence: Float,
        rawResponse: String
    ) {
        _plants.value = _plants.value.map {
            if (it.id == id) it.copy(
                familyCode = familyCode,
                familyName = familyName,
                familyLatin = familyLatin,
                speciesLatin = speciesLatin,
                chineseName = chineseName,
                confidence = confidence,
                rawResponse = rawResponse,
                status = RecognitionStatus.SUCCESS,
                errorMessage = ""
            ) else it
        }
    }

    private fun updatePlantError(id: String, error: String) {
        _plants.value = _plants.value.map {
            if (it.id == id) it.copy(
                status = RecognitionStatus.FAILED,
                errorMessage = error
            ) else it
        }
    }

    /**
     * 获取统计信息
     */
    fun getStats(): PlantStats {
        val list = _plants.value
        return PlantStats(
            total = list.size,
            selected = list.count { it.isSelected },
            pending = list.count { it.status == RecognitionStatus.PENDING },
            recognizing = list.count { it.status == RecognitionStatus.RECOGNIZING },
            success = list.count { it.status == RecognitionStatus.SUCCESS },
            failed = list.count { it.status == RecognitionStatus.FAILED },
            renamed = list.count { it.status == RecognitionStatus.RENAMED }
        )
    }
}

data class PlantStats(
    val total: Int = 0,
    val selected: Int = 0,
    val pending: Int = 0,
    val recognizing: Int = 0,
    val success: Int = 0,
    val failed: Int = 0,
    val renamed: Int = 0
)
